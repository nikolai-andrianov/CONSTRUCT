%  Global variables

%  Handles of main window and menuitems save, print, ..
    global MainWindow h11 h12 h13 h14 h2 charact axes1 axes2 choose_param varnames CSTR_Addmenu CSTR_ADDMENU
    global cmenu1 cmenu2 cmenu3							%  addmenu is reserved (standard function)

%  Phase color and linewidth
    global SolidColor GasColor CRLineWidth ShockLineWidth

%  Structures and their dimensions
    global Nwaves Nchar N			%  Number of items in wave menu, number of drawn characteristics and waves
    global colour wavename wavetype wave0 wave orig_wavename orig_wavetype paramname	%  See construct.m

%  Some input parameters
    global ga pia gb pib			%  Thermodynamic constants
    global U00 U0 aa1 ra1			%  State U0 to the left, aa1 and ra1 to the right of solid contact
    global XA XB XLIM YLIM x0 t mx x dx data	%  Domain, x and the data arrays

%  Used in behind_ua.n
    global ab1 M P E etab rb11 rb12 ua0

%  Filename and remark to solution
    global filename remark

%  Gas and solid control speeds
    global GSspeed SSspeed
