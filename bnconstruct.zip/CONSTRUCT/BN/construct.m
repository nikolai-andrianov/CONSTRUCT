function construct

% ##################################################################################
%  Construct the exact solution to the Riemann problem for the Baer-Nunziato model.
% ##################################################################################


%------------------------------------------------------------------------------
% Declare global variables
%------------------------------------------------------------------------------

  globals

%------------------------------------------------------------------------------
% Initialize
%------------------------------------------------------------------------------

%######################################
%  Constants

  SolidColor='-r';	%  Draw SOLID with red
  GasColor='-b';	%  Draw GAS with blue
  CRLineWidth=1;	%  Linewidth for Contact or Rarefaction
  ShockLineWidth=2;     %  Linewidth for Shock

%  Number of waves, which can be drawn (what appears in menu)

  Nwaves=9;

%  Number of drawn waves
  N=0;

%  Number of drawn characteristics
  Nchar=0;

  wavename=['Solid 1-shock      ';
	  'Solid 1-rarefaction';
	  'Gas 1-shock        ';
	  'Gas contact        ';
	  'Gas 1-rarefaction  ';
	  'Solid 3-shock      ';
	  'Solid 3-rarefaction';
	  'Gas 3-shock        ';
	  'Gas 3-rarefaction  '];
  orig_wavename=wavename;

  wavetype=['s1s';
	  's1r';
	  'g1s';
	  'g2c';
	  'g1r';
	  's3s';
	  's3r';
	  'g3s';
	  'g3r'];
  orig_wavetype=wavetype;
	
  paramname=['Solid volume fraction';
             'Solid density        ';
             'Solid velocity       ';
             'Solid pressure       ';
             'Gas density          ';
             'Gas velocity         ';
             'Gas pressure         ';];
	
	
   colour=['r','r','r','r','b','b','b'];		%  Colors for the paramname

   varnames=['aa0';'ra0';'ua0';'pa0';'rb0';'ub0';'pb0';'aa1';'ra1'];


%######################################
%  Main window

  FigWidth=0.6;
  FigHeight=0.8;

  FigPos(1)=(1-FigWidth)/2;
  FigPos(2)=(1-FigHeight)/2;
  FigPos(3)=FigWidth;
  FigPos(4)=FigHeight;

  MainWindow=figure;
  set(MainWindow,'Units','normalized', ...
  	 'Position', FigPos,...
  	 'NumberTitle','off', ...
  	 'MenuBar','None',...
  	 'Name','Construction of Riemann Problem');

%  Menu  	
  	
  h1=uimenu('Label', 'File');
  uimenu(h1, 'Label', 'New..','Callback', 'callbacks(0);')
  uimenu(h1, 'Label', 'Open..','Callback', 'callbacks(1);');
  h11=uimenu(h1, 'Label', 'Save configuration','Separator','On','Enable','Off','Callback', 'callbacks(5);');
  h12=uimenu(h1, 'Label', 'Save solution','Enable','Off','Callback', 'callbacks(6);');
  h13=uimenu(h1, 'Label', 'Print configuration',...
  		 'Enable','Off','Separator','On',...
  		 'Callback', 'callbacks(8);');
  h14=uimenu(h1, 'Label', 'Print solution','Enable','Off','Callback', 'callbacks(7);');
  uimenu(h1, 'Label', 'Quit','Separator','On','Callback', 'callbacks(2);');

  h2=uimenu('Label', 'Edit','Enable','Off');
  uimenu(h2, 'Label', 'Domain','Callback', 'callbacks(10);');
  uimenu(h2, 'Label', 'Phase constants','Callback', 'callbacks(11);');

  h3=uimenu('Label', 'Help','Enable','On');
  uimenu(h3, 'Label', 'Contents..','Callback', 'callbacks(12);');
  uimenu(h3, 'Label', 'About..','Separator','On','Callback', 'callbacks(13);');


%  Set some uicontrols empty

  axes1=[];		%  Bottom axes, for configuration
  axes2=[];		%  Top axes, for graphs		
  choose_param=[];	%  Popup for parameters to draw
  CSTR_Addmenu=[];		%  Context menu
  charact=[];		%  Characteristics

%  .. and also some parameters
  U0=[];
  wave0=[];
  filename='';
  remark='';
  answer={''};
				
