function WAVE=draw_wave(U,U1,WAVENAME,WAVETYPE,par)

%  Draws the wave of the type WAVETYPE, which
%  connects the state U with U1.
%  par is useful only in case of shock and is equal
%  to shock speed.

  globals 	

  axes(axes1);		%  Draw in the bottom axes

  PHASE=WAVETYPE(1);	%  's' or 'g'
  if PHASE == 's'
    phase='Solid';
  else
    phase='Gas';
  end
  FAMILY=str2num(WAVETYPE(2));	%  1 or 2
  TYPE=WAVETYPE(3);	%  's' or 'r'

  NN=60;
  Dx=1/NN;	%  Draw the rarefaction fan with the distance >= Dx between the lines

  aa0=U(1);
  ra0=U(2);
  ua0=U(3);
  pa0=U(4);
  rb0=U(5);
  ub0=U(6);
  pb0=U(7);

  if PHASE == 's'
      g=ga;
      pi=pia;
      r0=ra0;
      u0=ua0;
      p0=pa0;
  else
      g=gb;
      pi=pib;
      r0=rb0;
      u0=ub0;
      p0=pb0;
  end

  Aa1=U1(1);
  Ra1=U1(2);		%  ra1 is a global variable, always solid density at the right of solid contact
  ua1=U1(3);
  pa1=U1(4);
  rb1=U1(5);
  ub1=U1(6);
  pb1=U1(7);

  if PHASE == 's'
      g=ga;
      pi=pia;
      r1=Ra1;
      u1=ua1;
      p1=pa1;
  else
      g=gb;
      pi=pib;
      r1=rb1;
      u1=ub1;
      p1=pb1;
  end

  if PHASE == 's'
     PhaseColor=SolidColor;
     height=1/2;
     sphase='_a';		%  Phase "a" is solid
   else
     PhaseColor=GasColor;
     height=2/3;
     sphase='_b';		%  Phase "b" is gas
   end

   if TYPE == 's'
     LineWidth=ShockLineWidth;
   else
     LineWidth=CRLineWidth;
   end


   if TYPE == 'c'		%  Contact
     speed=u0;			%  Contact speed
     height=5/6;
     position=speed*t;
     txt=['\itu' sphase];
     alignment='right';
   end

   if TYPE == 'r'	 	%  Rarefaction

     c0=sqrt(g*(p0+pi)/r0);
     c1=sqrt(g*(p1+pi)/r1);

     if FAMILY == 1
      rartype=-1;	%  1-rarefaction		
     else
      rartype=1;	%  3-rarefaction
    end

    speed1=min(u0+rartype*c0, u1+rartype*c1);	%  The min char. in the rarefaction
    speed2=max(u0+rartype*c0, u1+rartype*c1);	%  The max char. in the rarefaction

    if FAMILY == 1
       txt=[phase ' rarefaction\rightarrow'];
       alignment='right';
       position=speed1*t;
    else
       txt=['\leftarrow' phase ' rarefaction'];
       alignment='left';
       position=speed2*t;
    end

   end

   if TYPE == 's'		%  Shock

     speed=par;

     if FAMILY == 1
       txt=[phase ' shock\rightarrow'];
       alignment='right';
     else
       txt=['\leftarrow' phase ' shock'];
       alignment='left';
     end

     position=speed*t;

   end



% #######################################
% Draw the waves

   WAVE.name=WAVENAME;
   WAVE.type=WAVETYPE;

   if TYPE == 'r'

     WAVE.speed1=speed1;
     WAVE.speed2=speed2;
     x1=x0+speed1*t;
     x2=x0+speed2*t;
     m=round((x2-x1)/Dx);
     if m ~= 0
       deltax=(x2-x1)/m;
     else
       deltax=x2-x1;
     end
     for i=1:m+1
       xx=x1+(i-1)*deltax;
       WAVE.handle(i)=plot([x0 xx],[0 t],PhaseColor);
       set(WAVE.handle(i),'UIContextMenu', cmenu2,'Visible','on');
     end
     WAVE.handle(m+2)=text(x0+position*height,t*height,txt,'HorizontalAlignment',alignment);
     set(WAVE.handle(m+2),'UIContextMenu', cmenu2,'Visible','on');

   else

     WAVE.speed1=speed;
     WAVE.speed2=speed;
     WAVE.handle(1)=plot([x0 x0+speed*t], [0 t], PhaseColor);
     set(WAVE.handle(1), 'LineWidth',LineWidth,'UIContextMenu', cmenu2,'Visible','on');
     WAVE.handle(2)=text(x0+position*height,t*height,txt,'HorizontalAlignment',alignment);
     set(WAVE.handle(2),'UIContextMenu', cmenu2,'Visible','on');

   end

