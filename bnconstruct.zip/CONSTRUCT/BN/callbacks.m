function callbacks(menuans)

%  Callbacks to construct.m

%------------------------------------------------------------------------------
% Declare global variables
%------------------------------------------------------------------------------

  globals

  saveformat=1;		%  Determines format for saving the solution (0 - old, 1 - new)

%------------------------------------------------------------------------------
%  Menu callbacks			
%------------------------------------------------------------------------------
					
  if ((menuans == 0) | (menuans == 1) | (menuans == 10) | (menuans == 11))	%  New or Open or Change domain

    data=[];

  if menuans == 0 				%  New configuration

    filename='';
    wavename=orig_wavename;		%  Restore original list of waves
    wavetype=orig_wavetype;
%  First delete some stuff which may remain after the previous session
    for i=1:Nchar
      delete(charact(i).handle);		% Delete charact's
    end
    charact=[];
    N=0;	
    Nchar=0;
    Nwaves=9;

   prompt={'Left interval bound','Right interval bound','Position of diaphragm','Number of cells', 'Output time'};
   title='Set domain';
   lines=1;
   def={num2str(0,16), num2str(1,16),num2str(0.5,16),num2str(300,16),num2str(0.1,16)};
   answer=inputdlg(prompt,title,lines,def);
   if isempty(answer),return;end
   XA=str2double(answer(1));
   XB=str2double(answer(2));
   x0=str2double(answer(3));
   mx=str2double(answer(4));
   t=str2double(answer(5));

   prompt={'Gamma for the solid phase','Pi for the solid phase','Gamma for the gas phase','Pi for the gas phase'};
   title='Set phase constants';
   lines=1;
   def={num2str(1.4,16), num2str(0,16),num2str(1.4,16),num2str(0,16)};
   answer=inputdlg(prompt,title,lines,def);
   if isempty(answer),return;end
   ga=str2double(answer(1));
   pia=str2double(answer(2));
   gb=str2double(answer(3));
   pib=str2double(answer(4));

   if isempty(U0)
     U0=zeros(1,7);
     aa1=0;
     ra1=0;
   end

   U1=inputsc;		%  Uses global U0,aa1,ra1, Sets U1 behind the solid contact. If bad U0, repeats attempts.
   if isempty(U1),return,end

   aa0=U0(1);
   ra0=U0(2);
   ua0=U0(3);
   pa0=U0(4);
   rb0=U0(5);
   ub0=U0(6);
   pb0=U0(7);

   Nread=0;			%  No other waves apart of solid contact

  elseif menuans == 1			%  Open configuration

    wavename=orig_wavename;		%  Restore original list of waves
    wavetype=orig_wavetype;
%  First delete some stuff which may remain after the previous session
    for i=1:Nchar
      delete(charact(i).handle);		% Delete charact's
    end
    charact=[];	
    N=0;		%  Number of drawn waves
    Nchar=0;
    Nwaves=9;

    FigWidth=340;	%  Dimensions of uigetfile
    FigHeight=350;

    set(MainWindow,'Units','pixels');
    FigSize=get(MainWindow,'Position');
    set(MainWindow,'Units','normalized');

    Xdlg=FigSize(1)+(FigSize(3)-FigWidth)/2;		% Xdlg,Ydlg are coordinates (in pixels) of the upper left corner of uigetfile or uiputfile
    ScreenSize=get(0,'ScreenSize');
    Yscreen=ScreenSize(4);
    Ydlg=Yscreen-(FigSize(2)+(FigSize(4)+FigHeight)/2);

    [Fn,Pn]=uigetfile('*.cnf', 'Open data file',Xdlg,Ydlg);	%  Fn is file name, Pn its path => [Pn,Fn] full name
    if Fn == 0,return,end

      fid=fopen([Pn,Fn]);
      filename=Fn;
      ll=fgetl(fid);				%  Get the first line: either 'Domain' or '###Remarks..'
      if ll(1:6) ~= 'Domain'
        remark='';
        while 1
          ll=fgetl(fid);		%  Get the second line
          dim=size(ll);
          dim1=size('###############################################');
          if dim(2)==dim1(2)
            if ll == '###############################################'
              break
            end
          end
          remark=str2mat(remark, ll);	%  Set al lines together
        end
%       h=msgbox(remark,'Remarks to solution');	%  Better do it later..
%        uiwait(h)
        fgetl(fid);				%  Get 'Domain'
      end

      XA=str2num(strtok(fgetl(fid), '%'));	%  XA: left interval bound
      XB=str2num(strtok(fgetl(fid), '%'));	%  XB: left interval bound
      x0=str2num(strtok(fgetl(fid), '%'));	%  Position of diaphragm
      mx=str2num(strtok(fgetl(fid), '%'));	%  Number of cells
      t=str2num(strtok(fgetl(fid), '%'));	%  Output time

      fgetl(fid);				%  Get 'Phase constants'
      ga=str2num(strtok(fgetl(fid), '%'));	%  Gamma for the solid phase
      pia=str2num(strtok(fgetl(fid), '%'));	%  Pi for the solid phase
      gb=str2num(strtok(fgetl(fid), '%'));	%  Gamma for the gas phase
      pib=str2num(strtok(fgetl(fid), '%'));	%  Pi for the gas phase

      fgetl(fid);				%  Get 'Parameters at U0 (left of solid contact)'
      aa0=str2num(strtok(fgetl(fid), '%'));	%  Solid volume fraction left
      ra0=str2num(strtok(fgetl(fid), '%'));	%  Solid density at U0
      ua0=str2num(strtok(fgetl(fid), '%'));	%  Solid velocity at U0
      pa0=str2num(strtok(fgetl(fid), '%'));	%  Solid pressure at U0
      rb0=str2num(strtok(fgetl(fid), '%'));	%  Gas density at U0
      ub0=str2num(strtok(fgetl(fid), '%'));	%  Gas velocity at U0
      pb0=str2num(strtok(fgetl(fid), '%'));	%  Gas pressure at  U0

      U0=[aa0,ra0,ua0,pa0,rb0,ub0,pb0];

      fgetl(fid);				%  Get 'Some parameters at U1 (right of solid contact)'
      aa1=str2num(strtok(fgetl(fid), '%'));	%  Solid volume fraction right
      ra1=str2num(strtok(fgetl(fid), '%'));	%  Solid density behind the Solid contact us

      fgetl(fid);				%  Get 'Waves'
      Nread=0;
      while ~feof(fid)
        Nread=Nread+1;
        str=strtok(fgetl(fid), '%');
        wave(Nread).lr=str(1);
        wave(Nread).type=str(2:4);
        strlen=size(str);
        wave(Nread).par=str2num(str(5:strlen(2)));
        for k=1:Nwaves
          this=1;
          for j=1:3
            if wave(Nread).type(j) ~=  wavetype(k,j),this=0;end
          end
          if this wave(Nread).name=wavename(k,:);end;
        end

      end

      fclose(fid);

  elseif menuans == 10			%  Set domain

   prompt={'Left interval bound','Right interval bound','Position of diaphragm','Number of cells', 'Output time'};
   title='Set domain';
   lines=1;
   def={num2str(XA,16), num2str(XB,16),num2str(x0,16),num2str(mx,16),num2str(t,16)};
   answer=inputdlg(prompt,title,lines,def);
   if ~isempty(answer)
     XA=str2double(answer(1));
     XB=str2double(answer(2));
     x0=str2double(answer(3));
     mx=str2double(answer(4));
     t=str2double(answer(5));
   end

   Nread=N;     	%  Used to redraw the waves
   N=0;			%  Number of drawn waves
%%%
   wavename=orig_wavename;		%  Restore original list of waves
   wavetype=orig_wavetype;
   Nwaves=9;
%%%

  else             %  menuans == 11	%  Set phase constants

   prompt={'Gamma for the solid phase','Pi for the solid phase','Gamma for the gas phase','Pi for the gas phase'};
   title='Set phase constants';
   lines=1;
   def={num2str(ga,16), num2str(pia,16),num2str(gb,16),num2str(pib,16)};
   answer=inputdlg(prompt,title,lines,def);
   if ~isempty(answer)
     ga=str2double(answer(1));
     pia=str2double(answer(2));
     gb=str2double(answer(3));
     pib=str2double(answer(4));
   end
   Nread=N;     	%  Used to redraw the waves
   N=0;			%  Number of drawn waves
%%%
   wavename=orig_wavename;		%  Restore original list of waves
   wavetype=orig_wavetype;
   Nwaves=9;
%%%


  end

  if ~isempty(axes1),delete(axes1);axes1=[];end
  if ~isempty(axes2),delete(axes2);axes2=[];end
  if ~isempty(choose_param),delete(choose_param);choose_param='';end

  XLIM=[XA XB];		%  Limits for zooming
  YLIM=[0 t];

  DOMLEN=XB-XA;
  dx=DOMLEN/mx;
  xa=XA+(1-0.5)*dx;	%  The first and the last points in the computational domain 	
  xb=XA+(mx-0.5)*dx;
  x=[xa:dx:xb];		%  The x-array
  x=x';			%  Transpose for convenience in plotting


  rb1=behind_ua;

  if isempty(rb1)	%  If there are no roots of F(rb)=0, or pa1<0, then input solid contact once again till U0,U1 is good.
    U1=inputsc;
    if isempty(U1),return,end
    rb1=U1(5);
  end

  aa0=U0(1);
  ra0=U0(2);
  ua0=U0(3);
  pa0=U0(4);
  rb0=U0(5);
  ub0=U0(6);
  pb0=U0(7);

  ab0=1-aa0;		
  ab1=1-aa1;

  ua1=ua0;
  ub1=M/(ab1*rb1)+ua1;
  pb1=((rb1/rb0)^gb)*(pb0+pib)-pib;
  pa1=1/aa1*(P-ab1*pb1-ab1*rb1*(ub1-ua1)^2);

  U1(1)=aa1;
  U1(2)=ra1;
  U1(3)=ua1;
  U1(4)=pa1;
  U1(5)=rb1;
  U1(6)=ub1;
  U1(7)=pb1;

  GSspeed=[ua0 ua1];		%  Gas Signal speeds
  SSspeed=[ua0 ua1];	


  set(h11,'Enable','On');	%  At this point, the parameters entered are okay and we can let the solution be saved or edited
  set(h12,'Enable','On');
  set(h13,'Enable','On');
  set(h14,'Enable','On');
  set(h2,'Enable','On');


%  Define the context menu1: child of axes, allows add waves, edit, delete them, draw characteristics, ...
     cmenu1 = uicontextmenu;

%  Define the context menu items
     INFOMENU= uimenu(cmenu1, 'Label', 'Info','Callback','callbacks(325);');

     ZOOMMENU1= uimenu(cmenu1, 'Label', 'Zoom in','Separator','On','Callback','callbacks(3);');
     ZOOMMENU2= uimenu(cmenu1, 'Label', 'Zoom out','Callback','callbacks(4);');

     CSTR_ADDMENU = uimenu(cmenu1, 'Label', 'Add wave','Separator','On');
       for i=1:Nwaves
	 CSTR_Addmenu(i)=uimenu(CSTR_ADDMENU,'Label',wavename(i,:),'Callback', ['callbacks(' num2str(300+i) ');']);
       end

     DRAWMENU = uimenu(cmenu1, 'Label', 'Draw');
       drawsolidchar=uimenu(DRAWMENU, 'Label', 'Draw solid characteristics','Callback','callbacks(320);');
       drawgaschar=uimenu(DRAWMENU, 'Label', 'Draw gas characteristics','Callback','callbacks(321);');

%  Define the context menu2: child of line (waves), allows to edit and delete them
     cmenu2 = uicontextmenu;
     EDITMENU = uimenu(cmenu2, 'Label', 'Edit wave','Separator','On','Callback','callbacks(350);');
     DELMENU  = uimenu(cmenu2, 'Label', 'Delete wave','Separator','On','Callback','callbacks(351);');

%  Define the context menu3: child of line (characteristics), allows to delete them
     cmenu3 = uicontextmenu;
     INFOMENU= uimenu(cmenu3, 'Label', 'Info','Callback','callbacks(323);');
     DELMENU = uimenu(cmenu3, 'Label', 'Delete','Separator','On','Callback','callbacks(322);');


%  Define the axes
    						%  If Edit solid contact, the axes1(2) are already there.
    						%  If for the first time, they are global => empty
    axes1=axes('Parent',MainWindow, ...
		'Position',[0.07 0.05 0.89 0.45],...
		'Tag','Axes1',...
		'XLim', [XA XB],...
		'YLim', [0 t],...
		'NextPlot', 'add',...		
		'UIContextMenu', cmenu1);	%  Axes for the Riemann problem
		
%    set(axes1,'XLabel','Position x');		%  DON'T KNOW WHY IT DOES NOT WORK...
    xlabel('Position x');
    ylabel('Time t')

    axes2=axes('Parent',MainWindow, ...
		'Position',[0.07 0.55 0.89 0.4],...
		'Tag','Axes2',...
		'XLim', [0 1],...
		'YLim', [0 1]);	%  Axes for the graphs

    choose_param=uicontrol('Parent',MainWindow, ...
    		'Units','normalized', ...
		'HorizontalAlignment','center', ...		
		'Position',[0.4 0.96 0.2 0.03],...		
		'String',paramname, ...
		'Style','popupmenu', ...
		'Callback','callbacks(400);', ...
		'HorizontalAlignment','left',...		
		'Tag','PopupMenu2', ...
		'Value',1);	
		
%    width=120;				% Width and height of popup in points
%    height=20;		
%    set(MainWindow,'Units','Points');
%    FigPos=get(MainWindow,'Position');
%    set(choose_param,'Units','Points');
%    PopupPos=get(choose_param,'Position');
%    set(choose_param,'Position',[(FigPos(3)-width)/2 PopupPos(2) width height]);
		
    U=sample(U0,'l','s2c',ua0,1);	% Sample the solution to the left and right of solid contact
    if isnan(U),return,end;

    U=sample(U1,'r','s2c',ua1,1);
    if isnan(U),return,end;

    axes(axes2);		%  Draw the first graph (volume fraction )in the top axes
    plot(x,data(:,1), colour(1));
    set(choose_param, 'Value',1);



    wave0=draw_wave(U0,U1,'Solid contact','s1c',1);	%  Draw solid contact: connects states U0 and U1, wavetype: (s)olid 1 (c)ontact,
    				%  par=1 (arbitrary number)

    Ul=U0;			%  Current end left and right states
    Ur=U1;

    for i=1:Nread

      if wave(i).lr == 'l'
        wave(i).U=Ul;
        if wave(i).type(1) == 'g'
          Sspeed=GSspeed(1);
        else
          Sspeed=SSspeed(1);
        end
      else
        wave(i).U=Ur;
        if wave(i).type(1) == 'g'
          Sspeed=GSspeed(2);
        else
          Sspeed=SSspeed(2);
        end
      end

      Unext=sample(wave(i).U,wave(i).lr,wave(i).type,Sspeed,wave(i).par);

      if ~isnan(Unext)
        temp_wave=draw_wave(wave(i).U,Unext,wave(i).name,wave(i).type,wave(i).par);
        N=N+1;     			%  Number of drawn waves
        wave(i).speed1=temp_wave.speed1;	%  The min and max speeds in the wave   TUT STOYAL wave(N)
        wave(i).speed2=temp_wave.speed2;
        wave(i).sign_speed=Sspeed;		%  Previous signal speed
        wave(i).handle=temp_wave.handle;	%  handle(s) to the lines which form the wave

        if wave(i).lr == 'l'			%  If the current wave is left, then set Ul equal to the state behind this wave
          Ul=Unext;
        else
          Ur=Unext;				%   		--	  right,   --	 Ur    		--
        end

        modifymenu(wave(i).type,'-');

      else

        break;

      end

    end

    if ~isempty(remark)
      h=msgbox(remark,'Remarks to solution');	%  Print the remarks
      uiwait(h)
      remark='';
    end

  end


  if menuans == 2
    MainWindow=gcbf;
%    answer=questdlg('Do you really want to quit?', ...
%    		    'Quit?',...
%    		    'Yes','No','Cancel',...
%    		    'Yes');
%    if strcmp(answer, 'Yes')
      delete(MainWindow);
%    end      		
  end



  if ((menuans == 3) | (menuans == 4))				%  Zoom in/out
      if menuans == 3
        k=1/2;		%  Zoom the axes by factor 1/2 (zoom in)
      else
        k=2;
      end

      CurrentPoint=get(axes1, 'CurrentPoint');
      xc=CurrentPoint(1,1);	%  Coordinates of the right-click
      tc=CurrentPoint(1,2);

      DX=XLIM(2)-XLIM(1);
      if xc <=XLIM(1)+DX/2
        XLIM(1)=max(XA, xc - k*DX/2);
        XLIM(2)=min(XB,XLIM(1) + k*DX);
      else
        XLIM(2)=min(XB, xc + k*DX/2);
        XLIM(1)=max(XA,XLIM(2) - k*DX);
      end

      DY=YLIM(2)-YLIM(1);
      if tc <= YLIM(1)+DY/2
        YLIM(1)=max(0, tc - k*DY/2);
        YLIM(2)=min(t,YLIM(1) + k*DY);
      else
        YLIM(2)=min(t, tc + k*DY/2);
        YLIM(1)=max(0,YLIM(2) - k*DY);
      end
      set(axes1, 'Xlim', XLIM, 'Ylim', YLIM);
  end



  if menuans == 5			%  Save configuration

   filename=strtok(filename,'.');	%  Cut the tail starting with .

    FigWidth=340;	%  Dimensions of uigetfile
    FigHeight=350;

    set(MainWindow,'Units','pixels');
    FigSize=get(MainWindow,'Position');
    set(MainWindow,'Units','normalized');

    Xdlg=FigSize(1)+(FigSize(3)-FigWidth)/2;		% Xdlg,Ydlg are coordinates (in pixels) of the upper left corner of uigetfile or uiputfile
    ScreenSize=get(0,'ScreenSize');
    Yscreen=ScreenSize(4);
    Ydlg=Yscreen-(FigSize(2)+(FigSize(4)+FigHeight)/2);


   [Fn,Pn]=uiputfile([filename '.cnf'], 'Save configuration',Xdlg,Ydlg);	%  Fn is file name, Pn its path => [Pn,Fn] full name
    if Fn ~= 0

      fid=fopen([Pn,Fn],'w+');

      prompt={'Your remarks:'};
      title='Remarks to the solution';
      lines=10;
      answer=inputdlg(prompt,title,lines);
      if ~isempty(answer)
        answer=cell2struct(answer,'text');
        fprintf(fid,'##############Remarks to solution##############\n');
        dim=size(answer.text);
        for i=1:dim(1)
          fprintf(fid,'%s\n',answer.text(i,:));
        end
        fprintf(fid,'###############################################\n');
      end

      fprintf(fid,'%s  \n','Domain');
      fprintf(fid,'%s\t %% %s\n', num2str(XA,16), 'a: left interval bound');
      fprintf(fid,'%s\t %% %s\n', num2str(XB,16), 'b: right interval bound');
      fprintf(fid,'%s\t %% %s\n', num2str(x0,16), 'Position of diaphragm');
      fprintf(fid,'%s\t %% %s\n', num2str(mx,16), 'Number of cells');
      fprintf(fid,'%s\t %% %s\n', num2str(t,16), 'Output time');
      fprintf(fid,'%s  \n','Phase constants');
      fprintf(fid,'%s\t %% %s\n', num2str(ga,16), 'Gamma for the solid phase');
      fprintf(fid,'%s\t %% %s\n', num2str(pia,16), 'Pi for the solid phase');
      fprintf(fid,'%s\t %% %s\n', num2str(gb,16), 'Gamma for the gas phase');
      fprintf(fid,'%s\t %% %s\n', num2str(pib,16), 'Pi for the gas phase');
      fprintf(fid,'%s  \n','Parameters at U0 (left of solid contact)');

      str=str2mat('Solid volume fraction left','Solid density at U0','Solid velocity at U0','Solid pressure at U0','Gas density at U0','Gas velocity at U0','Gas pressure at  U0');

      for i=1:7
        fprintf(fid,'%s\t %% %s\n', num2str(U0(i),16), str(i,:));
      end

      fprintf(fid,'%s  \n','Some parameters at U1 (right of solid contact)');
      fprintf(fid,'%s\t %% %s\n', num2str(aa1,16), 'Solid volume fraction right');
      fprintf(fid,'%s\t %% %s\n', num2str(ra1,16), 'Solid density behind the solid contact');

      fprintf(fid,'%s  \n','Waves');
      for i=1:N
        if wave(i).lr == 'l'
          lr='Left';
        else
          lr='Right';
        end
        fprintf(fid,'%s%s %s\t %% %s %s\n', wave(i).lr, wave(i).type, num2str(wave(i).par,16), lr, lower(wave(i).name));
      end

      fclose(fid);
    end


  end


  if menuans == 6			%  Save solution

   filename=strtok(filename,'.');	%  Cut the tail starting with .

%  First save the direct Riemann problem

    FigWidth=340;	%  Dimensions of uigetfile
    FigHeight=350;

    set(MainWindow,'Units','pixels');
    FigSize=get(MainWindow,'Position');
    set(MainWindow,'Units','normalized');

    Xdlg=FigSize(1)+(FigSize(3)-FigWidth)/2;		% Xdlg,Ydlg are coordinates (in pixels) of the upper left corner of uigetfile or uiputfile
    ScreenSize=get(0,'ScreenSize');
    Yscreen=ScreenSize(4);
    Ydlg=Yscreen-(FigSize(2)+(FigSize(4)+FigHeight)/2);


    [Fn,Pn]=uiputfile([filename '.rp'], 'Save Riemann problem',Xdlg,Ydlg);	%  Fn is file name, Pn its path => [Pn,Fn] full name
    if Fn ~= 0
      fid=fopen([Pn,Fn],'w+');

      if saveformat == 0		%  Old format

      fprintf(fid,'%s\t ! %s\n', num2str(DOMLEN,16), 'Domain length');
      fprintf(fid,'%s\t ! %s\n', num2str(x0,16), 'Position of diaphragm');
      fprintf(fid,'%s\t ! %s\n', num2str(mx,16), 'Number of cells');
      fprintf(fid,'%s\t ! %s\n', num2str(ga,16), 'Gamma for the solid phase');
      fprintf(fid,'%s\t ! %s\n', num2str(pia,16), 'Pi for the solid phase');
      fprintf(fid,'%s\t ! %s\n', num2str(gb,16), 'Gamma for the gas phase');
      fprintf(fid,'%s\t ! %s\n', num2str(pib,16), 'Pi for the gas phase');
      fprintf(fid,'%s\t ! %s\n', num2str(t,16), 'Output time');      		
      str=str2mat('Solid volume fraction','Solid density','Solid velocity','Solid pressure','Gas density','Gas velocity','Gas pressure');
      for i=1:7
        fprintf(fid,'%s\t ! %s\n', num2str(data(1,i),16), str(i,:));
      end
      for i=1:7
        fprintf(fid,'%s\t ! %s\n', num2str(data(mx,i),16), str(i,:));
      end		
      		
      else				%  Better format

      fprintf(fid,'%s  \n','Domain');
      fprintf(fid,'%s\t ! %s\n', num2str(XA,16), 'a: left interval bound');
      fprintf(fid,'%s\t ! %s\n', num2str(XB,16), 'b: right interval bound');
      fprintf(fid,'%s\t ! %s\n', num2str(x0,16), 'Position of diaphragm');
      fprintf(fid,'%s\t ! %s\n', num2str(mx,16), 'Number of cells');
      fprintf(fid,'%s\t ! %s\n', num2str(t,16), 'Output time');
      fprintf(fid,'%s  \n','Phase constants');
      fprintf(fid,'%s\t ! %s\n', num2str(ga,16), 'Gamma for the solid phase');
      fprintf(fid,'%s\t ! %s\n', num2str(pia,16), 'Pi for the solid phase');
      fprintf(fid,'%s\t ! %s\n', num2str(gb,16), 'Gamma for the gas phase');
      fprintf(fid,'%s\t ! %s\n', num2str(pib,16), 'Pi for the gas phase');
      fprintf(fid,'%s  \n','Parameters at the left state');
      str=str2mat('Solid volume fraction','Solid density','Solid velocity','Solid pressure','Gas density','Gas velocity','Gas pressure');
      for i=1:7
        fprintf(fid,'%s\t ! %s\n', num2str(data(1,i),16), str(i,:));
      end
      fprintf(fid,'%s  \n','Parameters at the right state');
      for i=1:7
        fprintf(fid,'%s\t ! %s\n', num2str(data(mx,i),16), str(i,:));
      end

      end

      fclose(fid);

    end

%  Save the sampled Riemann solution

    FigWidth=340;	%  Dimensions of uigetfile
    FigHeight=350;

    set(MainWindow,'Units','pixels');
    FigSize=get(MainWindow,'Position');
    set(MainWindow,'Units','normalized');

    Xdlg=FigSize(1)+(FigSize(3)-FigWidth)/2;		% Xdlg,Ydlg are coordinates (in pixels) of the upper left corner of uigetfile or uiputfile
    ScreenSize=get(0,'ScreenSize');
    Yscreen=ScreenSize(4);
    Ydlg=Yscreen-(FigSize(2)+(FigSize(4)+FigHeight)/2);


   [Fn,Pn]=uiputfile([filename '.exact'], 'Save solution',Xdlg,Ydlg);	%  Fn is file name, Pn its path => [Pn,Fn] full name
    if Fn ~= 0
      fid=fopen([Pn,Fn],'w+');

%  Save in the OLD format only..

      if saveformat == 0		%  Old format
         fprintf(fid,'t=   %.16e\\\\ \n', t);
         for i=1:mx
           aa=data(i,1);
 	   ra=data(i,2);
	   ua=data(i,3);
	   pa=data(i,4);
	   rb=data(i,5);
	   ub=data(i,6);
	   pb=data(i,7);
	   ab=1-aa;
           ea=(pa+ga*pia)/ra/(ga-1);
           eb=(pb+gb*pib)/rb/(gb-1);
           fprintf(fid,'\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\t\t%.16e\n', x(i), aa*ra, 0, aa*ra*ua, ea, ab*rb, 0, ab*rb*ub, eb, 0, 0, 0, aa, ra, rb, pa, pb);
         end

      else		

%        prompt={'Your remarks:'};
%        title='Remarks to the solution';
%        lines=10;
%        answer=inputdlg(prompt,title,lines,answer);	%  The default lines at the input field are the old remarks
%        answer=cell2struct(answer,'text');
%        if ~isempty(answer)
%          fprintf(fid,'##############Remarks to solution##############\n');
%          dim=size(answer.text);
%          for i=1:dim(1)
%            fprintf(fid,'%s\n',answer.text(i,:));
%          end
%          fprintf(fid,'###############################################\n');
%        end

	fprintf(fid,'t=%.16e\n', t);
	fprintf(fid,'Fields: (x,aa,ra,ua,pa,rb,ub,pb)\n\n');
	
        for n=1:mx
          fprintf(fid,'%.16e\t%.16e\t%.16e\t%.16e\t%.16e\t%.16e\t%.16e\t%.16e\n', x(n),data(n,:));
        end

      end
      fclose(fid);

    end

  end

  if menuans == 7			%  Print solution

    str={'Solid parameters';'Gas parameters'};
    [parnum,sel]=listdlg('Name','Choose parameters','PromptString','You wish to print','ListString',str);

    if sel

      dim=size(parnum);
      if dim(2) ==  2   		%  Print both parameters
        drawfig=draw(t,x,'s',data);
        set(drawfig,'Visible','Off');
        h=printdlg(drawfig);
        uiwait(h);
        delete(drawfig);

        drawfig=draw(t,x,'g',data);
        set(drawfig,'Visible','Off');
        h=printdlg(drawfig);
        uiwait(h);
        delete(drawfig);
      else
        if parnum == 1
          PHASE='s';
        else
          PHASE='g';
        end
        drawfig=draw(t,x,PHASE,data);
        set(drawfig,'Visible','Off');
        h=printdlg(drawfig);
%        uiwait(h);
        delete(drawfig);
      end

    end

  end

  if menuans == 8			%  Print configuration

   printdlg(MainWindow,[0 0 1 0.47],get(gcf,'defaultaxesposition'),choose_param);	% Under Windows, prints not only the configuration, but also smth of the upper part of MainWindow..
  end

  if menuans == 12			%  Launch external browser with help.html

    str=which('construct.m');		
    DIR=strrep(str,'construct.m','');	%  Get the directory, where the files of construct are located
    web(['file://' DIR 'construct.html']);

  end


  if menuans == 13			%  About msgbox

    str1='CONSTRUCT v1.0';
    str2='Author: Nikolai Andrianov';
    str3='Nikolai.Andrianov@Mathematik.Uni-Magdeburg.DE';
    str=str2mat(str1,str2,str3);
    msgbox(str,'About')

  end







%------------------------------------------------------------------------------
%  Context menu callbacks
%------------------------------------------------------------------------------


  if menuans == 110		%  Calculate the state behind solid contact

%  Read the new values

    for i=1:7
     U0(i)=str2double(get(sc1ed(i), 'String'));
     if ((U0(i) <= 0) & ((i ~= 3) & (i ~= 6)))
       errordlg(['Please enter POSITIVE ' varnames(i) '!'])
     end
    end

    aa0=U0(1);
    ra0=U0(2);
    ua0=U0(3);
    pa0=U0(4);
    rb0=U0(5);
    ub0=U0(6);
    pb0=U0(7);

    aa1=str2double(get(sc1ed(8), 'String'));
    if aa1 <= 0
       errordlg('Please enter POSITIVE aa1!')
    end

    ra1=str2double(get(sc1ed(9), 'String'));
    if ra1 <= 0
       errordlg('Please enter POSITIVE ra1!')
    end

    rb1=behind_ua;

    if isempty(rb1)
      return;
    end

    ab0=1-aa0;		%  Parameters aa0, ra0, .. already determined by Open or New.
    ab1=1-aa1;

    ua1=ua0;
    ub1=M/(ab1*rb1)+ua1;
    pb1=((rb1/rb0)^gb)*(pb0+pib)-pib;
    pa1=1/aa1*(P-ab1*pb1-ab1*rb1*(ub1-ua1)^2);

    U1(1)=aa1;
    U1(2)=ra1;
    U1(3)=ua1;
    U1(4)=pa1;
    U1(5)=rb1;
    U1(6)=ub1;
    U1(7)=pb1;

    GSspeed=[ua0 ua1];		%  Gas Signal speeds
    SSspeed=[ua0 ua1];	

		
    U=sample(U0,'l','s2c',ua0,1);	% Sample the solution to the left and right of solid contact
    U=sample(U1,'r','s2c',ua1,1);

    axes(axes2);		%  Draw the first graph (volume fraction )in the top axes
    plot(x,data(:,1), colour(1))
    set(choose_param, 'Value',1);


    wave0=draw_wave(U0,U1,'Solid contact','s1c',1);	%  Draw solid contact: connects states U0 and U1, wavetype: (s)olid 1 (c)ontact,
    				%  par=1 (arbitrary number)


  end


  if ((menuans >= 300) & (menuans <= 300+Nwaves))		%  Have chosen "Add wave" contextmenu

    wave_choice=menuans-300;
    CurrentPoint=get(axes1, 'CurrentPoint');
    xc=CurrentPoint(1,1);	%  Coordinates of the right-click
    tc=CurrentPoint(1,2);
    xx=(xc-x0)*t/tc+x0;		%  (xx,t) is the point at the same ray at time t

    if xc <= x0+ua0*tc		%  If it was clicked to the left or right of the solid contact
      lr='l';
      ic=floor((xx-XA)/dx +0.5);	%  Current index of xx at time t: Closest integer below xc

      if wavetype(wave_choice,1) == 'g'
        if xc >= x0+GSspeed(1)*tc
          errordlg(['This state does not lies to the left of the gas signal speed!']);
          return;
        else
          Sspeed=GSspeed(1);
        end
      end

      if wavetype(wave_choice,1) == 's'
        if xc >= x0+SSspeed(1)*tc
          errordlg(['This state does not lies to the left of the solid signal speed!']);
          return;
        else
          Sspeed=SSspeed(1);
        end
      end

    else
      lr='r';
      ic=ceil((xx-XA)/dx +0.5);	%  Current index of xx at time t: Closest integer above xc

      if wavetype(wave_choice,1) == 'g'
        if xc <= x0+GSspeed(2)*tc
          errordlg(['This state does not lies to the right of the gas signal speed!']);
          return;
        else
          Sspeed=GSspeed(2);
        end
      end

      if wavetype(wave_choice,1) == 's'
        if xc <= x0+SSspeed(2)*tc
          errordlg(['This state does not lies to the right of the solid signal speed!']);
          return;
        else
          Sspeed=SSspeed(2);
        end
      end

    end

    X=x0+Sspeed*t;		%  Make sampling starting from (X,t)

    if ((ic >= 1) & (ic <= mx))
      U=data(ic,:);		%  Current state at (xc,tc)
    elseif ic < 1
      U=data(1,:);
    else
      U=data(mx,:);
    end

    if wavetype(wave_choice,3) == 's'		% Shock
      prompt='Enter shock speed:';
    elseif wavetype(wave_choice,3) == 'r'	% Rarefaction
      prompt='Enter pressure behind the rarefaction:';	
    else				        % Contact
      prompt='Enter density behind the contact:';
    end

    title=['Add ' lower(deblank(wavename(wave_choice,:)))];
    lines=1;
    parstr=inputdlg(prompt,title,1);
    if isempty(parstr),return,end;

    par=str2double(parstr);

    if isnan(par)
      errordlg(['Please enter a NUMBER!']);
      return;
    end

    if ~isempty(par)
      Unext=sample(U,lr,wavetype(wave_choice,:),Sspeed,par);

      if ~isnan(Unext)
        temp_wave=draw_wave(U,Unext,wavename(wave_choice,:),wavetype(wave_choice,:),par);
        N=N+1;     			%  Number of drawn waves
        wave(N).name=temp_wave.name;		%  Wave name
        wave(N).type=temp_wave.type;		%  type
        wave(N).lr=lr;				%  The wave is at the left/right to solid contact
        wave(N).par=par;			%  Parameter which determines the state behind it
        wave(N).U=U;				%  The state before it
        wave(N).speed1=temp_wave.speed1;	%  The min and max speeds in the wave
        wave(N).speed2=temp_wave.speed2;
        wave(N).sign_speed=Sspeed;		%  Previous signal speed
        wave(N).handle=temp_wave.handle;	%  handle(s) to the lines which form the wave

        modifymenu(wavetype(wave_choice,:),'-');

      end

    end

  end

  if ((menuans == 320) | (menuans == 321))	%  Draw characteristics

      CurrentPoint=get(axes1, 'CurrentPoint');
      xc=CurrentPoint(1,1);	%  Coordinates of the right-click
      tc=CurrentPoint(1,2);
      xx=(xc-x0)*t/tc+x0;		%  (xx,t) is the point at the same ray at time t
      ic=round((xx-XA)/dx +0.5);	%  Current index of xx
      if ((ic >= 1) & (ic <= mx))
        U=data(ic,:);		%  Current state at (xc,tc)
      elseif ic < 1
        U=data(1,:);
      else
        U=data(mx,:);
      end

%  Create new charact structure: three characteristics, going out of one point (xc,tc)

      Nchar=Nchar+1;			%  This will be the Nchar's structure
      charact(Nchar).pos=[xc tc];	%  Coordinates of the point (xc,tc)
      charact(Nchar).U=U;		%  U at (xc,tc)

      if menuans == 320		%  Draw solid characteristics
        charact(Nchar).phase='s';
        charact(Nchar).handle=show_char(xc,tc,U,'s');
      else
        charact(Nchar).phase='g';
        charact(Nchar).handle=show_char(xc,tc,U,'g');
      end


  end



  if menuans == 322			%  Delete charact

    hh=get(MainWindow, 'CurrentObject');

%  Looking which charact has the line with the handle hh
    i=1;
    stop=0;
    while ((i <= Nchar) & (~stop))
      for k=1:3		%  charact(..).handle has always three components (line handles)
        if charact(i).handle(k) == hh
          delete(charact(i).handle);
%          Nchar=Nchar-1;		
%  Don't decrease Nchar, because we do not necessarily delete charact's in the same order as we created them!!
%  In principle one should make the list with pointers..
	  stop=1;		
	  for j=i:Nchar-1
	    charact(j)=charact(j+1);
	  end
	  Nchar=Nchar-1;
	  stop=1;
        end
      end
      i=i+1;
    end


  end

  if menuans == 323			%  Info on charact

    hh=get(MainWindow, 'CurrentObject');

%  Looking which charact has the line with the handle hh

    current=0;
    for i=1:Nchar
      for k=1:3		%  charact(..).handle has always three components (line handles)
        if charact(i).handle(k) == hh
          current=1;
          break;	%  The current charact is charact(i)
        end
      end

      if current

        U=charact(i).U;
        xc=charact(i).pos(1);	%  Coordinates of the point (xc,tc)
        tc=charact(i).pos(2);	%  Coordinates of the point (xc,tc)

        if charact(i).phase == 's'
          u=U(3);
          c=sqrt(ga*(U(4)+pia)/U(2));
          title='Solid characteristics';
        else
          u=U(6);
          c=sqrt(gb*(U(7)+pib)/U(5));
          title='Gas characteristics';
        end

        str=str2mat(['x: ' num2str(xc,16)], ['t: ' num2str(tc,16)], ' ');
        str=str2mat(str,['u-c: ', num2str(u-c,16)],['u: ', num2str(u,16)],['u+c: ', num2str(u+c,16)]);
        msgbox(str,title);
        break;

      end

    end

  end


  if menuans == 325			%  Info on current state U

    CurrentPoint=get(axes1, 'CurrentPoint');
    xc=CurrentPoint(1,1);	%  Coordinates of the right-click
    tc=CurrentPoint(1,2);
    xx=(xc-x0)*t/tc+x0;		%  (xx,t) is the point at the same ray at time t
    ic=round((xx-XA)/dx +0.5);	%  Current index of xx
    if ((ic >= 1) & (ic <= mx))
        U=data(ic,:);		%  Current state at (xc,tc)
    elseif ic < 1
        U=data(1,:);
    else
        U=data(mx,:);
    end

    str=str2mat(['x: ' num2str(xc,16)], ['t: ' num2str(tc,16)], ' ');
    for i=1:7
      str1=[varnames(i,1:2) ': ' num2str(U(i),16)];
      str=str2mat(str,str1);
    end
    msgbox(str,'Current state');

  end


  if menuans == 350		%  Edit wave

    hh=get(MainWindow, 'CurrentObject');

%  First check if the solid contact is chosen

   if ((wave0.handle(1) == hh) | (wave0.handle(2) == hh))

     answer=questdlg(['Attention: All waves will be deleted! Continue?'], 'Edit solid contact', 'Yes','Cancel','Yes');

    if strcmp(answer, 'Yes')

      U0old=U0;				%  Save for the case if bad values will be entered
      aa1old=aa1;
      ra1old=ra1;

      U1=inputsc;
      if isempty(U1),return,end

      ua0=U0(3);
      ua1=U1(3);

      GSspeed=[ua0 ua1];		%  Gas Signal speeds
      SSspeed=[ua0 ua1];	

      wavename=orig_wavename;		%  Restore original list of waves
      wavetype=orig_wavetype;

      for i=1:Nwaves
        delete(CSTR_Addmenu(i));		% Delete the old menu items
      end
      for i=1:N
        delete(wave(i).handle);		%  Delete all lines of all waves
      end	
      wave=[];
      delete(wave0.handle)
      wave0=[];					%  Don't really understand why we can't use clear wave0. In doing so, wave0 remains the old one..

      for i=1:Nchar
        delete(charact(i).handle);		% Delete charact's
      end
      charact=[];

      N=0;	
      Nchar=0;
      Nwaves=9;
      for i=1:Nwaves
        CSTR_Addmenu(i)=uimenu(CSTR_ADDMENU,'Label',wavename(i,:),'Callback', ['callbacks(' num2str(300+i) ');']);
      end

		
      U=sample(U0,'l','s2c',ua0,1);	% Sample the solution to the left and right of solid contact
      U=sample(U1,'r','s2c',ua1,1);

      axes(axes2);		%  Draw the first graph (volume fraction) in the top axes

      plot(x,data(:,1), colour(1))

      set(choose_param, 'Value',1);

      wave0=draw_wave(U0,U1,'Solid contact','s1c',1);	%  Draw solid contact: connects states U0 and U1, wavetype: (s)olid 1 (c)ontact,
    				%  par=1 (arbitrary number)
    		
    end
 	

   end

%  Looking which wave has the line with the handle hh

    current=0;
    for i=1:N
      nlines=size(wave(i).handle);
      nlines=nlines(2);			%  Current wave consists of nlines lines
      for k=1:nlines
        if wave(i).handle(k) == hh
          current=1;
          break;	%  The current wave is wave(i)
        end
      end

      if current

        if wave(i).type(3) == 's'		% Shock
	  prompt='Enter shock speed:';
        elseif wave(i).type(3) == 'r'	% Rarefaction
          prompt='Enter pressure behind the rarefaction:';	
        else				        % Contact
          prompt='Enter density behind the contact:';
        end

        title=['Edit ' lower(deblank(wave(i).name))];
        def={num2str(wave(i).par)};
        parstr=inputdlg(prompt,title,1,def);
        if isempty(parstr),return,end;
        newpar=str2double(parstr);

        if isnan(newpar)
          errordlg(['Please enter a NUMBER!']);
          return;
        end

        if ~isempty(newpar)

          Unext=sample(wave(i).U,wave(i).lr,wave(i).type,wave(i).sign_speed,newpar);	% Try to find the new wave with signal speed = sign_speed

          if ~isnan(Unext)		%  If it is admissible, then..
            Type=[wave(i).type(1:2) 'f'];
            sample(wave(i).U,wave(i).lr,Type,wave(i).sign_speed,1);		% First want to fill data with U starting from sign_speed

%  Here U is the state before the wave(i), Unext the state after it

	    Unext=sample(wave(i).U,wave(i).lr,wave(i).type,wave(i).sign_speed,newpar);	% The new wave with signal speed = sign_speed
	
	    delete(wave(i).handle);	%  Remove the old wave
	
	    temp_wave=draw_wave(wave(i).U,Unext,wave(i).name,wave(i).type,newpar);
            wave(i).par=newpar;			%  Parameter which determines the state behind it
            wave(i).speed1=temp_wave.speed1;	%  The min and max speeds in the wave
            wave(i).speed2=temp_wave.speed2;
            wave(i).handle=temp_wave.handle;	%  handle(s) to the lines which form the wave

            if wave(i).lr == 'l'
              Sspeed=wave(i).speed1;		%  Signal speed for the k-th wave
            else
              Sspeed=wave(i).speed2;
            end

%  Modify all PHASE waves to lr of the current one

	    skip=0;
	    for k=1:N
	      if ((wave(k).type(1) == wave(i).type(1)) & (wave(k).lr == wave(i).lr) & (k ~=i)) 	%  If both of the same PHASE and lr
	
	        if ( ((wave(k).lr == 'l') & (wave(k).speed1 <  wave(i).speed2)) | ((wave(k).lr == 'r') & (wave(k).speed2 >  wave(i).speed1)) )	%  k-th wave does not lie completely between previous wave and i-th wave
	
	          if wave(k).lr == 'l'
	             xx=x0+Sspeed*t;		%  (t,xx) is the point on the min speed of the wave
     		     ic=floor((xx-XA)/dx +0.5);			%  Closest integer below xx
     		  else
	             xx=x0+Sspeed*t;			%  (t,xx) is the point on the max speed of the wave
     		     ic=ceil((xx-XA)/dx +0.5);			%  Closest integer above xx
     		  end
	
	          wave(k).sign_speed=Sspeed;	
	          delete(wave(k).handle)
     		  U=data(ic,:);			%  U there; ic always lies in [1,mx] since we don't allow the waves leave the computational domain in sample
     		  Unext=sample(U,wave(k).lr,wave(k).type,Sspeed,wave(k).par);	% Find the state behind the wave(k)using the OLD wave(k).par
          	  if ((~isnan(Unext)) & (~skip))		%  If it is admissible or skip calculations at all, then..
                     temp_wave=draw_wave(U,Unext,wave(k).name,wave(k).type,wave(k).par);
	             wave(k).speed1=temp_wave.speed1;	%  The min and max speeds in the wave
            	     wave(k).speed2=temp_wave.speed2;
	             wave(k).handle=temp_wave.handle;	%  handle(s) to the lines which form the wave
	             wave(k).U=U;
	             Sspeed=wave(k).speed1;		%  Signal speed as determined by wave(k)    	
	          else
	             modifymenu(wave(k).type,'+');	%  Add to menu the wave(s) of the same type as wave(k)
	             for j=k:N-1
	               wave(j)=wave(j+1);
	             end
	             skip=1;	
	             N=N-1;			%  Number of drawn waves
	          end
	
	        end
	
	      end
	
	    end
	
%  End modify..	
	
          end

        end

        break;

      end

    end

  end


  if menuans == 351		%  Delete wave

   hh=get(MainWindow, 'CurrentObject');

%  First check if the solid contact is chosen

   if ((wave0.handle(1) == hh) | (wave0.handle(2) == hh))

     answer=questdlg(['Attention: All waves will be deleted! Continue?'], 'Delete solid contact', 'Yes','Cancel','Yes');

    if strcmp(answer, 'Yes')

      wavename=orig_wavename;		%  Restore original list of waves
      wavetype=orig_wavetype;

      for i=1:Nwaves
         delete(CSTR_Addmenu(i));		% Delete the old menu items
      end
      for i=1:N
         delete(wave(i).handle);		%  Delete all lines of all waves
      end
      wave=[];
      delete(wave0.handle)
      wave0=[];

      for i=1:Nchar
         delete(charact(i).handle);		% Delete charact's
      end
      charact=[];

      N=0;	
      Nchar=0;
      Nwaves=9;
      for i=1:Nwaves
         CSTR_Addmenu(i)=uimenu(CSTR_ADDMENU,'Label',wavename(i,:),'Callback', ['callbacks(' num2str(300+i) ');']);
      end

      delete(axes1)
      delete(axes2)
      delete(choose_param)

%  Set some uicontrols empty

      axes1=[];		%  Bottom axes, for configuration
      axes2=[];		%  Top axes, for graphs		
      choose_param=[];	%  Popup for parameters to draw
      CSTR_Addmenu=[];		%  Context menu
      charact=[];		%  Characteristics

      data=[];

      set(h11,'Enable','Off');	%  At this point, the parameters entered are okay and we can let the solution be saved or edited
      set(h12,'Enable','Off');
      set(h13,'Enable','Off');
      set(h14,'Enable','Off');

      set(h2,'Enable','Off');

    end
    return;
   end

%  Consider the rest of waves

%  Looking which wave has the line with the handle hh

   current=0;
   for i=1:N
      nlines=size(wave(i).handle);
      nlines=nlines(2);			%  Current wave consists of nlines lines
      for k=1:nlines
        if wave(i).handle(k) == hh
          current=1;
          break;	%  The current wave is wave(i)
        end
      end

      if current

        current=0;

        if wave(i).lr == 'l'
          lr='left';
        else
          lr='right';
        end
        if wave(i).type(1) == 's'
          PHASE='solid';
        else
          PHASE='gas';
        end

        name=lower(deblank(wave(i).name));
        str=['Attention: All ' PHASE ' waves to the ' lr ' of ' name ' will be deleted! Continue?'];
        answer=questdlg(str, ['Delete ' name], 'Yes','Cancel','Yes');

        if strcmp(answer, 'Cancel'), return; end


        Type=[wave(i).type(1:2) 'f'];

        sample(wave(i).U,wave(i).lr,Type,wave(i).sign_speed,1);		% First want to fill data with U starting from sign_speed

%  Here U is the state before the wave(i), Unext the state after it


%  Delete all waves which are of the same phase, lr, and completely at the left or right of wave(i)

%  First mark which waves should be deleted in array KD

	kd=0;		%  Number of waves to delete
        for k=1:N

	   if ((wave(k).type(1) == wave(i).type(1)) & (wave(k).lr == wave(i).lr)) 	%  If both of the same PHASE and lr

	      if ( ((wave(k).lr == 'l') & (wave(k).speed1 <=  wave(i).speed2)) | ((wave(k).lr == 'r') & (wave(k).speed2 >=  wave(i).speed1)) )	%  k-th wave does not lie completely between previous wave and i-th wave
	
	         delete(wave(k).handle);
                 modifymenu(wave(k).type,'+');	%  Add to menu the wave(s) of the same type as wave(k)
                 kd=kd+1;
                 KD(kd)=k;			%  wave(k) should be deleted


              end
           end
        end

        NN=0;

%  Initialize newwave as a structure, e.g. with wave0 when no waves are drawn and with wave(1) otherwise
        if N==0
          newwave=wave0;
        else
          newwave=wave(1);
        end

        for i=1:N		%  Now look through all waves if they have to be deleted or not
           marked=0;
           for j=1:kd
              if (i == KD(j)),marked=1;break;end
           end
           if ~marked
             NN=NN+1;
             newwave(NN)=wave(i);		%  Copy all non-marked waves to newvave
           end
        end
        N=NN;			%  Number of drawn waves
        wave=[];
        wave=newwave;
        newwave=[];

        break			%  break the loop on line 1298, where the waves were checked, if they were clicked or not

      end
   end

  end


  if menuans == 400		%  Plot graph

    axes(axes2);		%  Draw in the top axes
    parnum=get(choose_param, 'Value');
    plot(x,data(:,parnum), colour(parnum));
    xlim([XA XB])

  end
