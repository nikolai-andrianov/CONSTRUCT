function rb1=behind_ua

%  Evaluates the state U1 behind the solid contact ua.

  globals

  rb1=[];		% Returns the empty value if coinciding contacts or no roots

  aa0=U0(1);
  ra0=U0(2);
  ua0=U0(3);
  pa0=U0(4);
  rb0=U0(5);
  ub0=U0(6);
  pb0=U0(7);

  ab0=1-aa0;
  ab1=1-aa1;

  if ub0 == ua0
    h=errordlg('Coinciding contacts: ua=ub0 !!');
    uiwait(h);
    return
  end

  M=ab0*rb0*(ub0-ua0);
  P=aa0*pa0 + ab0*pb0 + ab0*rb0*(ub0-ua0)^2;
  E=0.5*(ub0-ua0)^2 + gb*(pb0+pib)/rb0/(gb-1);
  etab=(pb0+pib)/(rb0^gb);


  rbstar=( M^2/ab1^2/gb/etab )^(1/(gb+1));

  rb=rbstar/2;		% /* Initial guess to find the smallest root */
  interv(1)=0;		% /* Interval bounds for the smallest root */
  interv(2)=rbstar;
  EPS=1e-8;

  use_fzero=0;
  for i=1:2

      F=1;
      niter=0;

      while (abs(F)>EPS)

         niter=niter+1;		%	/* Number of iterations */
         if (rem(niter,100) == 0)
            disp([num2str(niter) ' iterations in finding the ' num2str(i) ' root behind the stat. contact..']);
            disp('Using fzero..');
            use_fzero=1;
            return;
         end;

         F=0.5*(M/ab1./rb).^2 + gb*etab*rb.^(gb-1)/(gb-1) - E;	%   /* F(rb) */
         Fder=-M*M/(ab1*ab1*rb*rb*rb) + gb*etab*(rb^(gb-2));	%	/* F'(rb)*/

         if (abs(Fder)<EPS),disp('In finding the state behind the stationary contact, |F`(rho)|<EPS !!');end;

         if (Fder==0)
            disp('In finding the state behind the stationary contact, |F`(r)|=0 !!');
            return;
         end

         rb=rb-F/Fder;		%  /* Newton iteration */

         if (rb < interv(1)),rb=EPS;end;
         if (rb > interv(2)),rb=rbstar-EPS;end;

      end

      if (use_fzero),return,end;

      if (i==1)
        rb11=rb;
        rb=3*rbstar/2;		% /* Initial guess to find the biggest root */
        interv(1)=rbstar;	% /* Interval bounds for the biggest root */
        interv(2)=1e10;		% /* Some big value */
      else
        rb12=rb;
      end

  end

  if (use_fzero)
    rb11=fzero('F',rbstar);
    rb12=fzero('F',rb0);
  end


  if (isnan(rb11) | isnan(rb11))
     str=['F(rb1)=0 has no roots! Please change the parameters on the solid contact.'];
     h=errordlg(str);
     uiwait(h);
     return;
  else

%  Check if they are different

  stp=0;
  while (abs(rb11-rb12) < 1e-8)

    rbstar=rb0;
    fp=figure;
    set(fp, 'NumberTitle','Off','Name','Graph of F(rb)=0');
    drb=2*rbstar/100;
%    rb=[0.001:drb:2*rbstar];

    if rb11 < rbstar
      ARB=rb11;
      BRB=rbstar+(rbstar-rb11)/2;
    else
      ARB=max(0.0001, rbstar-(rb11-rbstar)/2);
      BRB=rb11;
    end

    drb=(BRB-ARB)/100;
    rb=[ARB:drb:BRB];

    plot(rb,F(rb));
    title('Graph of F(\rho_b)');
    ylabel('F(\rho_b)');
    xlabel('\rho_b');

    Title='Find zero of F(rb)=0';
    str1='Across the solid contact, the equation F(rb)=0 has two roots.';
    str2=['With the following starting guess fzero.m has converged to ' num2str(rb11)];
    str3='Enter another starting guess to find the second root:';
    prompt=str2mat(str1,str2,str3);
    def={num2str(rbstar)};
    parstr=inputdlg(prompt,Title,1,def);
    if isempty(parstr),stp=1;delete(fp);return;end;
    rbstar=str2double(parstr);
    if (isnan(rbstar) | rbstar < 0)
      h=errordlg(['Please enter a positive NUMBER!']);
      uiwait(h);
      delete(fp);
    else
      rb12=fzero('F',rbstar);
      delete(fp);
      if (isnan(rb12)),rb12=rb11;end;
    end

  end


  if stp,return,end

%  Determine which one is admissible

     cb02=gb*(pb0+pib)/rb0;

     ua1=ua0;
     ub11=M/(ab1*rb11)+ua1;
     pb1=((rb11/rb0)^gb)*(pb0+pib)-pib;
     cb11=gb*(pb1+pib)/rb11;

     ub12=M/(ab1*rb12)+ua1;
     pb1=((rb12/rb0)^gb)*(pb0+pib)-pib;
     cb12=gb*(pb1+pib)/rb12;

     found=0;
     if sign((ub11-ua1)^2-cb11) == sign((ub0-ua0)^2-cb02)	%  rb11 admissible
       rb1=rb11;
       found=1;
     end

     if sign((ub12-ua1)^2-cb12) == sign((ub0-ua0)^2-cb02)	%  rb12 admissible
       rb1=rb12;
       if found
          h=errordlg('The both two roots are admissible !!');
          uiwait(h);
          rb1=[];
          return;
       end
       found=1;
     end

     if ~found

       if sign((ub0-ua0)^2-cb02) == 0
         str1='Sonic state attached to the solid contact at the left !!';
         str2='Exiting..';
         str=str2mat(str1,str2);
         h=errordlg(str);
         uiwait(h);
         rb1=[];
         return;
       end

       fp=figure;
       set(fp, 'NumberTitle','Off','Name','Graph of F(rb)=0');
       drb=abs((rb12-rb11)/100);
       rb=[rb11-0.01:drb:rb12+0.01];
       plot(rb,F(rb));
       grid on
%       title('Graph of F(\rho_b)');				%  Don't know why it does not work..
       ylabel('F(\rho_b)');
       xlabel('\rho_b');

       disp(['rb11=' num2str(rb11,16) '  rb12=' num2str(rb12,16)]);

       h=errordlg('None of the two roots are admissible !!');
       uiwait(h);
       rb1=[];
       return;
     end


    ua1=ua0;
    ub1=M/(ab1*rb1)+ua1;
    pb1=((rb1/rb0)^gb)*(pb0+pib)-pib;
    pa1=1/aa1*(P-ab1*pb1-ab1*rb1*(ub1-ua1)^2);

    if pa1 <= 0
      str1=['Not positive solid pressure! pa1=' num2str(pa1)];
      str2='Please change the parameters on the solid contact.';
      str=str2mat(str1,str2);
      rb1=[];
      h=errordlg(str);
      uiwait(h);
      return;
    end

%  Check:

  E1=0.5*(ub1-ua0)^2 + gb*(pb1+pib)/rb1/(gb-1);
  if abs(E1-E) > EPS
    h=errordlg(['Error in behind_us: E1-E2' num2str(E1-E2)]);
    uiwait(h);
    return;
  end


  end





