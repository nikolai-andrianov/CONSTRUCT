function Y=F(rb1);

%  Finds the zeros of the function F(rb1)=0

  globals

%  ab1 is defined in behind_ua and is a global variable

  Y = 0.5*(M/ab1./rb1).^2 + gb*etab*rb1.^(gb-1)/(gb-1) - E;

