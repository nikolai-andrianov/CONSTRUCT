function drawfig=draw(varargin)

%  If called without any arguments, asks for the data file with results,
%  which phase results to draw, and draws them.
%
%  If called with arguments, these should have the form
%  varargin{}={t,x,PHASE,data}, where
%	t is the time
%	x is the array of x
%	PHASE='s' or 'g' depending on which phase you want to draw
%	data is the array of (aa,ra,ua,pa,rb,ub,pb).
%
%  Returns the handle of the figure.


  if nargin == 0

%    prompt={'Print results from'};		%  Uncomment theses lines if you want graphic input
%    Title='Print solution';
%    lines=1;
%    fname=inputdlg(prompt,Title,lines);

    fname=input('Draw results from: ', 's');

    if isempty(fname),return;end

%    fname=cell2struct(fname,'str');		%  Uncomment theses lines if you want graphic input
%    fname=fname.str;

    fid = fopen(fname);
    if fid == -1
      disp(['Can''t open ' fname]);
      return;
    end
    str = fscanf(fid,'%s',1);			%  Get current time
    t=round(str2num(strrep(str,'t=',''))*100000)/100000;
    fscanf(fid,'%s %s',2);			%  Get 'Fields: ..'

    data = fscanf(fid,'%g',[8,inf]);
    data = data';
    fclose(fid);

    x=data(:,1);
    aa=data(:,2);
    ra=data(:,3);
    ua=data(:,4);
    pa=data(:,5);
    rb=data(:,6);
    ub=data(:,7);
    pb=data(:,8);

    PHASE=input('Draw results for solid(s) or gas(g) phase? ', 's');

  else

    t=varargin{1};
    x=varargin{2};
    PHASE=varargin{3};
    data=varargin{4};
    aa=data(:,1);
    ra=data(:,2);
    ua=data(:,3);
    pa=data(:,4);
    rb=data(:,5);
    ub=data(:,6);
    pb=data(:,7);

  end


%  Plotting..

  if PHASE == 's'
    phase='Solid';
    PhaseColor='r';
    Title='Solid parameters';
    r=ra;
    u=ua;
    p=pa;
  else
    phase='Gas';
    PhaseColor='b';
    Title='Gas parameters';
    r=rb;
    u=ub;
    p=pb;
  end

  drawfig=figure;
  set(drawfig,'NumberTitle','off','Name',Title);

  subplot(2,2,1);
  plot(x,r,PhaseColor);
  xlim([min(x) max(x)]);
  title([phase ' density at time t=',num2str(t) ]);

  subplot(2,2,2)
  plot(x,u,PhaseColor);
  xlim([min(x) max(x)]);
  title([phase ' velocity'])

  subplot(2,2,3)
  plot(x,p,PhaseColor);
  xlim([min(x) max(x)]);
  title([phase ' pressure'])

  subplot(2,2,4)
  plot(x,aa,'-r');
  xlim([min(x) max(x)]);
  title('Solid volume fraction')

