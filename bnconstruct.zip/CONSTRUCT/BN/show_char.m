function characts = show_char(xc,tc,U,PHASE);

%  Show the PHASE characteristics at the state U.
%  Returns handles to the graphs of characteristics.

  globals

  if PHASE == 's'
      g=ga;
      pi=pia;
      r=U(2);
      u=U(3);
      p=U(4);
  else
      g=gb;
      pi=pib;
      r=U(5);
      u=U(6);
      p=U(7);
  end

  c=sqrt(g*(p+pi)/r);

%  Set the size of characteristics
  T=get(axes1, 'YLim');
  dT=(T(2)-T(1))/4;		%  The t-component of the line is 1/4 of current t-scale

  if PHASE == 'g'
    PhaseColor=GasColor;
  else
    PhaseColor=SolidColor;
  end

  speed=u-c;
  characts(1)=plot([xc xc+speed*dT], [tc, tc+dT], PhaseColor);
  speed=u;
  characts(2)=plot([xc xc+speed*dT], [tc, tc+dT], PhaseColor);
  speed=u+c;
  characts(3)=plot([xc xc+speed*dT], [tc, tc+dT], PhaseColor);

  for i=1:3
    set(characts(i),'UIContextMenu', cmenu3,'Visible','on');
  end