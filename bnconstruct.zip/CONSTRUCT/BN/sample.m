function U1=sample(U,lr,WAVETYPE,SIGN_SPEED,par)

%  Samples the solution, i.e., fills the array data.
%  starting from the current wave, where the state before it is U,
%  in the direction lr.


  globals 	

  PHASE=WAVETYPE(1);	%  's' or 'g'
  FAMILY=str2num(WAVETYPE(2));	%  1, 2 or 3
  TYPE=WAVETYPE(3);	%  's', 'r', or 'f' (fill)

  U1=NaN;		%  To avoid that U1 will be undefined if the wave is not admissible.

  aa0=U(1);
  ra0=U(2);
  ua0=U(3);
  pa0=U(4);
  rb0=U(5);
  ub0=U(6);
  pb0=U(7);

  if PHASE == 's'
      g=ga;
      pi=pia;
      r0=ra0;
      u0=ua0;
      p0=pa0;
      sign_speed=SSspeed;
  else
      g=gb;
      pi=pib;
      r0=rb0;
      u0=ub0;
      p0=pb0;
      sign_speed=GSspeed;
  end

  		
%##############################################################################
%  Shock
%##############################################################################

  if TYPE == 's'

    s=par;		%  par is now the shock speed

    if ((x0+s*t > XB) | (x0+s*t < XA))
      str1=['The shock leaves the computational domain [' num2str(XA,16) ',' num2str(XB,16) ']!'];
      str2='Please reduce the shock speed or change the domain.';
      str=str2mat(str1,str2);
      h=errordlg(str);         uiwait(h)
      return;
    end

    if ((lr == 'l') & (s > SIGN_SPEED))
      str1='Cannot connect the current state with shock from the left!';
      str2=[' Shock speed s=' num2str(s,16) '>' num2str(SIGN_SPEED,16) ' (current left signal speed)'];
      str=str2mat(str1,str2);
      h=errordlg(str);         uiwait(h)
      return;
    end

    if ((lr == 'r') & (s < SIGN_SPEED))
      str1='Cannot connect the current state with shock from the right!';
      str2=[' Shock speed s=' num2str(s,16) '<' num2str(SIGN_SPEED,16) ' (current right signal speed)'];
      str=str2mat(str1,str2);
      h=errordlg(str);         uiwait(h)
      return;
    end

    mu2=(g-1)/(g+1);		%  Formulae from Courant and Friedrichs, p. 150.
    v0=u0-s;
    c2=g*(p0+pi)/r0;
    M0=abs(v0/sqrt(c2));

    p1=p0*(M0*M0*(1+mu2)-mu2)+g*pi*(1-mu2)*(M0*M0-1);

    if p1 < 0
      str1='Negative pressure behind the shock!';
      str2=['Pressure p=' num2str(p1,16)];
      str=str2mat(str1,str2);
      h=errordlg(str);         uiwait(h)
      return;
    end

    cstar2=mu2*v0^2 + (1-mu2)*c2;
    v1=cstar2/v0;
    u1=v1+s;
    c2=(cstar2-mu2*v1*v1)/(1-mu2);
    r1=g*(p1+pi)/c2;

%  Checks:

    if abs(r0*v0-r1*v1) > 1e-10
      msgbox('beda..')
      disp(num2str(r0*v0-r1*v1,16))
      pause
    end
    if abs(r0*v0^2+p0-r1*v1^2-p1) > 1e-10
      msgbox('beda..')
      disp(num2str(r0*v0^2+p0-r1*v1^2-p1,16))
      pause
    end
    if abs(v0^2/2+g*(p0+pi)/r0/(g-1) - v1^2/2-g*(p1+pi)/r1/(g-1)) > 1e-10
      msgbox('beda.. in energy balance')
      disp(num2str((v0^2/2+g*(p0+pi)/r0/(g-1) - v1^2/2-g*(p1+pi)/r1/(g-1)),16))
      pause
    end

    if lr == 'l'

      if ((FAMILY == 1) & ((p0 < p1) | (u0 > u1)))
        str1='Non-admissible 1-shock!';
        if p0 < p1, str2=['Pressure behind the shock p0=' num2str(p0,16) '<' num2str(p1,16) '=p1 (pressure before the shock)'];end
        if u0 > u1, str2=['Velocity behind the shock u0=' num2str(u0,16) '>' num2str(u1,16) '=u1 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      if ((FAMILY == 3) & ((p1 < p0) | (u1 < u0)))
        str1='Non-admissible 3-shock!';
        if p1 < p0, str2=['Pressure behind the shock p1=' num2str(p1,16) '<' num2str(p0,16) '=p0 (pressure before the shock)'];end
        if u1 < u0, str2=['Velocity behind the shock u1=' num2str(u1,16) '<' num2str(u0,16) '=u0 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      sign_speed(1)=s;		%  Can connect the current state with the shock from the left;
      				%  => left signal speed = s.
      				
%  For sampling:
      xx=x0+s*t;		%  (t,xx) is the point on the shock wave
      ic=floor((xx-XA)/dx +0.5);	%  Closest integer below xx
      di=-1;
      iend=1;

    else

      if ((FAMILY == 1) & ((p1 < p0) | (u1 > u0)))
        str1='Non-admissible 1-shock!';
        if p1 < p0, str2=['Pressure behind the shock p1=' num2str(p1,16) '<' num2str(p0,16) '=p0 (pressure before the shock)'];end
        if u1 > u0, str2=['Velocity behind the shock u1=' num2str(u1,16) '>' num2str(u0,16) '=u0 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;

      end

      if ((FAMILY == 3) & ((p0 < p1) | (u0 < u1)))
        str1='Non-admissible 3-shock!';
        if p0 < p1, str2=['Pressure behind the shock p0=' num2str(p0,16) '<' num2str(p1,16) '=p1 (pressure before the shock)'];end
        if u0 < u1, str2=['Velocity behind the shock u0=' num2str(u0,16) '<' num2str(u1,16) '=u1 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end


      sign_speed(2)=s;		%  Can connect the current state with the shock from the right;
      				%  => right signal speed = s.
      				
%  For sampling:
      xx=x0+s*t;		%  (t,xx) is the point on the shock wave
      ic=ceil((xx-XA)/dx +0.5);	%  Closest integer above xx
      di=1;			%  Step
      iend=mx;			%  Sample until

    end


%------------------------------------------------------------------------------
%  Sample the solution at the time t to the left or right of s
%------------------------------------------------------------------------------

    for i=ic:di:iend
      if PHASE == 's'
         data(i,2)=r1;		%  Fill data with SOLID parameters until i=1
         data(i,3)=u1;	
         data(i,4)=p1;	
      else
         data(i,5)=r1;		%  Fill data with GAS parameters until i=1
         data(i,6)=u1;	
         data(i,7)=p1;
      end
    end


  end


%##############################################################################
%  Rarefaction
%##############################################################################

  if TYPE == 'r'

    c0=sqrt(g*(p0+pi)/r0);

    if FAMILY == 1
      rartype=-1;	%  1-rarefaction		
    else
      rartype=1;		%  3-rarefaction
    end

    l1=u0+rartype*c0;	%  Begin of the rarefaction

    if par <= 0
      errordlg(['Enter POSITIVE pressure behind the rarefaction!']);
      return;
    end

    p1=par;		%  par now is the pressure behind the rarefaction

    r1=r0*((p1+pi)/(p0+pi))^(1/g);	%  Density
    c1=sqrt(g*(p1+pi)/r1);		%  Sound speed                              	
    u1=u0+rartype*2*c0/(g-1)*( ((p1+pi)/(p0+pi))^((g-1)/2/g)-1 );

    l2=u1+rartype*c1;	%  End of the rarefaction

    spd=max(abs(l1),abs(l2));
    if spd == abs(l1), spd=l1;end
    if spd == abs(l2), spd=l2;end

    if ((x0+spd*t > XB) | (x0+spd*t < XA))
      str1=['The rarefaction leaves the computational domain [' num2str(XA,16) ',' num2str(XB,16) ']!'];
      str2='Please change the rarefaction parameters or the domain.';
      str=str2mat(str1,str2);
      h=errordlg(str);         uiwait(h)
      return;
    end


    if lr == 'l'

      if l1 > SIGN_SPEED
        str1='Cannot connect the current state with rarefaction from the left!';
        str2=[' Rarefaction begin l1=' num2str(l1,16) '>' num2str(SIGN_SPEED,16) ' (current left signal speed)'];
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end


      if ((FAMILY == 1) & ((p0 > p1) | (u0 < u1)))
        str1='Non-admissible 1-rarefaction!';
        if p0 > p1, str2=['Pressure behind the rarefaction p0=' num2str(p0,16) '>' num2str(p1,16) '=p1 (pressure before the rarefaction)'];end
        if u0 < u1, str2=['Velocity behind the rarefaction u0=' num2str(u0,16) '<' num2str(u1,16) '=u1 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      if ((FAMILY == 3) & ((p1 > p0) | (u1 > u0)))
        str1='Non-admissible 3-rarefaction!';
        if p1 > p0, str2=['Pressure behind the rarefaction p1=' num2str(p1,16) '>' num2str(p0,16) '=p0 (pressure before the rarefaction)'];end
        if u1 > u0, str2=['Velocity behind the rarefaction u1=' num2str(u1,16) '>' num2str(u0,16) '=u0 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      sign_speed(1)=l2;		%  Can connect the current state with the rarefaction from the left;
      				%  => left signal speed = char. speed at the end of rarefaction.
    		
%  For sampling:
      xl1=x0+l1*t;
      il1=floor((xl1-XA)/dx +0.5);	%  Index, corresponding to the begin of the rarefaction
      xl2=x0+l2*t;
      il2=ceil((xl2-XA)/dx +0.5);	%  Index, corresponding to the end of the rarefaction

      a=(il1-0.5)*dx;		%  Corresponding x's.
      b=(il2-0.5)*dx;
      di=-1;
      iend=1;			%  Sample until

    else

      if l1 < SIGN_SPEED
        str1='Cannot connect the current state with rarefaction from the right!';
        str2=[str1 ' Rarefaction begin l1=' num2str(l1,16) '<' num2str(SIGN_SPEED,16) ' (current right signal speed)'];
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      if ((FAMILY == 1) & ((p1 > p0) | (u1 < u0)))
        str1='Non-admissible 1-rarefaction!';
        if p1 > p0, str2=['Pressure behind the rarefaction p1=' num2str(p1,16) '>' num2str(p0,16) '=p0 (pressure before the rarefaction)'];end
        if u1 < u0, str2=['Velocity behind the rarefaction u1=' num2str(u1,16) '<' num2str(u0,16) '=u0 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      if ((FAMILY == 3) & ((p0 > p1) | (u0 > u1)))
        str1='Non-admissible 3-rarefaction!';
        if p0 > p1, str2=['Pressure behind the rarefaction p0=' num2str(p0,16) '>' num2str(p1,16) '=p1 (pressure before the rarefaction)'];end
        if u0 > u1, str2=['Velocity behind the rarefaction u0=' num2str(u0,16) '>' num2str(u1,16) '=u1 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      sign_speed(2)=l2;		%  Can connect the current state with the rarefaction from the right;
      				%  => right signal speed = char. speed at the end of rarefaction.
      				
     	
%  For sampling:
      xl1=x0+l1*t;
      il1=floor((xl1-XA)/dx +0.5);	%  Index, corresponding to the begin of the rarefaction
      xl2=x0+l2*t;
      il2=ceil((xl2-XA)/dx +0.5);	%  Index, corresponding to the end of the rarefaction

      a=(il1-0.5)*dx;		%  Corresponding x's.
      b=(il2-0.5)*dx;
      di=1;
      iend=mx;			%  Sample until

    end


%------------------------------------------------------------------------------
%  Sample the solution at the time t in the rarefaction and to the left(right) of it
%------------------------------------------------------------------------------

    for i=il1:di:il2		%  Solution in the rarefaction fan
	
     xx=(i-0.5)*dx;		%  Current x

     if abs(b-a) > 1e-8
	xrel=(xx-a)/(b-a);
     else
	xrel=0;
     end
	
     xt=l1*(1-xrel)+l2*xrel;
	
     c=(g-1)/(g+1)*(-rartype*u0+2*c0/(g-1)+rartype*xt);
     u=xt-rartype*c;
     p=(p0+pi)*(c/c0)^(2*g/(g-1))-pi;
     r=r0*((p+pi)/(p0+pi))^(1/g);
	
     if PHASE == 's'
       data(i,2)=r;		%  Fill data with SOLID parameters
       data(i,3)=u;	
       data(i,4)=p;	
     else
       data(i,5)=r;		%  Fill data with GAS parameters
       data(i,6)=u;	
       data(i,7)=p;
     end

    end

    for i=il2:di:iend
        if PHASE == 's'
          data(i,2)=r1;		%  Fill data with SOLID parameters until i=iend
          data(i,3)=u1;	
          data(i,4)=p1;	
        else
          data(i,5)=r1;		%  Fill data with GAS parameters until iend
          data(i,6)=u1;	
          data(i,7)=p1;
        end
    end
	


  end


%##############################################################################
%  Contact
%##############################################################################

  if TYPE == 'c'

  if ((x0+u0*t > XB) | (x0+u0*t < XA))
      str1=['The contact leaves the computational domain [' num2str(XA,16) ',' num2str(XB,16) ']!'];
      str2='Please reduce the contact speed or change the domain.';
      str=str2mat(str1,str2);
      h=errordlg(str);
      uiwait(h)
      return;
  end

  if PHASE == 'g'

    if par <= 0
      errordlg(['Enter POSITIVE density behind the contact!']);
      return;
    end

    r1=par;
    u1=u0;
    p1=p0;


    if lr == 'l'

      if u0 > SIGN_SPEED
        str1='Cannot connect the current state with gas contact from the left!';
        str2=[str1 ' Contact speed u0=' num2str(u0,16) '>' num2str(SIGN_SPEED,16) ' (current left signal speed)'];
        str=str2mat(str1,str2);
        h=errordlg(str);       uiwait(h)
        return;
      end

      sign_speed(1)=u0;		%  Can connect the current state with the contact from the left;
      				%  => left signal speed = speed of contact.

 		
%  Sample the solution at the time t to the left of u0

      xx=x0+u0*t;		%  (t,xx) is the point on the contact
      ic=floor((xx-XA)/dx +0.5);	%  Closest integer below xx
      for i=ic:-1:1
          data(i,5)=r1;		%  Fill data with GAS parameters until i=1
          data(i,6)=u1;	
          data(i,7)=p1;
      end

    else

      if u0 < SIGN_SPEED
        str1='Cannot connect the current state with gas contact from the right!';
        str2=[str1 ' Contact speed u0=' num2str(u0,16) '<' num2str(SIGN_SPEED,16) ' (current left signal speed)'];
        str=str2mat(str1,str2);
        h=errordlg(str);         uiwait(h)
        return;
      end

      sign_speed(2)=u0;		%  Can connect the current state with the contact from the right;
      				%  => right signal speed = speed of contact.


%  Sample the solution at the time t to the right of s

      xx=x0+u0*t;		%  (t,xx) is the point on the contact
      ic=ceil((xx-XA)/dx +0.5);	%  Closest integer above xx
      for i=ic:+1:mx
          data(i,5)=r1;		%  Fill data with GAS parameters until i=1
          data(i,6)=u1;	
          data(i,7)=p1;
      end

    end

  else

% For solid PHASE just sample the solution with given U

     U1=U;			%  Set U1=U0, only for check if the solid contact is not out of domain

     if lr == 'l'

        xx=x0+u0*t;
        ic=floor((xx-XA)/dx +0.5);	%  Current index of X: Closest integer below X
        for i=ic:-1:1
          for k=1:7
            data(i,k)=U(k);	%  Fill data with U0 until i=1
          end
        end

      else

        xx=x0+u0*t;
        ic=ceil((xx-XA)/dx +0.5);	%  Current index of X: Closest integer above X
        for i=ic:+1:mx
          for k=1:7
            data(i,k)=U(k);	%  Fill data with U1 until i=mx
          end
        end

      end

      return;

  end

  end

%##############################################################################
%  Fill data with U from lr-side, starting from speed SIGN_SPEED (used to Edit wave )
%##############################################################################

  if TYPE == 'f'	%  fill

    r1=r0;
    u1=u0;
    p1=p0;

    if lr == 'l'

      sign_speed(1)=SIGN_SPEED;	%  Set the left signal speed
                                      		
%  Sample the solution at the time t to the left of SIGN_SPEED

      xx=x0+SIGN_SPEED*t;
      ic=floor((xx-XA)/dx +0.5);	%  Closest integer below xx
      for i=ic:-1:1
        if PHASE == 's'
          data(i,2)=r1;		%  Fill data with SOLID parameters until i=1
          data(i,3)=u1;	
          data(i,4)=p1;	
        else
          data(i,5)=r1;		%  Fill data with GAS parameters until i=1
          data(i,6)=u1;	
          data(i,7)=p1;
        end
      end

    else

      sign_speed(2)=SIGN_SPEED;	%  Set the right signal speed

%  Sample the solution at the time t to the right of s

      xx=x0+SIGN_SPEED*t;	
      ic=ceil((xx-XA)/dx +0.5);	%  Closest integer above xx
      for i=ic:+1:mx
        if PHASE == 's'
          data(i,2)=r1;		%  Fill data with SOLID parameters until i=mx
          data(i,3)=u1;	
          data(i,4)=p1;	
        else
          data(i,5)=r1;		%  Fill data with GAS parameters until i=mx
          data(i,6)=u1;	
          data(i,7)=p1;
        end
      end

    end

  end


%##############################################################################
%  Common for every wave
%##############################################################################


  U1(1)=U(1);		%  Solid volume fraction does not change across the waves

  if PHASE == 's'

      U1(2)=r1;		%  Current wave is solid; r1, u1, p1 are just found
      U1(3)=u1;
      U1(4)=p1;
      U1(5)=U(5);	%  Gas parameters do not change across solid wave
      U1(6)=U(6);
      U1(7)=U(7);
      SSspeed=sign_speed;

  else

      U1(2)=U(2);	%  Solid parameters do not change across gas wave
      U1(3)=U(3);
      U1(4)=U(4);
      U1(5)=r1;		%  Current wave is solid; r1, u1, p1 are just found
      U1(6)=u1;
      U1(7)=p1;
      GSspeed=sign_speed;

  end


%##############################################################################
%  Plot currently requested data in the popup menu
%##############################################################################

  axes(axes2);		%  Draw in the top axes
  parnum=get(choose_param, 'Value');
  plot(x,data(:,parnum), colour(parnum));
  xlim([XA XB]);

%##############################################################################

