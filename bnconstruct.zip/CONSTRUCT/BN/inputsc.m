function U1=inputsc

%  Creates a dialog window to enter the values around the solid contact, i.e.
%  sets the values of global varaibles U0,aa1,ra1.
%  Checks if they are positive if necessary.
%
%  With these parameters, tries to find the state behind the solid contact,
%  asking to correct the values of U0,aa1,ra1, if there are no roots or if pa1<0.
%
%  Input parameters (U,aa,ra) serve as a default values for the dialog entries.
%  Returns the state U1 behind the solid contact.

  globals

  U1=[];

  U0old=U0;				%  Save for the case if bad values will be entered
  aa1old=aa1;
  a1old=ra1;

  okay=0;
  stp=0;
  while ~okay

    okay=1;

    prompt={'Solid volume fraction at the left';
              'Solid density at the left';
              'Solid velocity at the left';
              'Solid pressure at the left';
              'Gas density at the left';
              'Gas velocity at the left';
              'Gas pressure at the left';
              'Solid volume fraction at the right';
              'Solid density at the right'};
    def={num2str(U0(1),16);num2str(U0(2),16);num2str(U0(3),16);num2str(U0(4),16);num2str(U0(5),16);num2str(U0(6),16);num2str(U0(7),16);
       num2str(aa1,16);num2str(ra1,16)};

    title='Enter solid contact';
    lines=1;

    answer=inputdlg(prompt,title,lines,def);
    if isempty(answer),stp=1;break;end

%  Read the new values for U0

    stp=0;
    for i=1:7
      U0(i)=str2double(answer(i));
      if ((U0(i) <= 0) & ((i ~= 3) & (i ~= 6)))
        par=cell2struct(prompt(i),'name');
        h=errordlg(['Please enter POSITIVE ' lower(par.name) '!']);
        uiwait(h);
        okay=0;
      end
    end

    aa1=str2double(answer(8));
    if aa1 <= 0
      h=errordlg('Please enter POSITIVE solid volume fraction at the right!');
      uiwait(h);
      okay=0;
    end

    ra1=str2double(answer(9));
    if ra1 <= 0
      h=errordlg('Please enter POSITIVE solid density at the right!');
      uiwait(h);
      okay=0;
    end

    rb1=behind_ua;		%  Calculates rb1 using just entered U0,aa1,ra1

    if isempty(rb1),okay=0;end

  end

  if stp,return,end		%  This is executed only if smb has pressed cancel.. Then return U1=[]

%  At this point, U0 is okay, so we can calculate U1 without problems..

  aa0=U0(1);
  ra0=U0(2);
  ua0=U0(3);
  pa0=U0(4);
  rb0=U0(5);
  ub0=U0(6);
  pb0=U0(7);

  ab0=1-aa0;	
  ab1=1-aa1;

  ua1=ua0;
  ub1=M/(ab1*rb1)+ua1;				%  Globals M,P,E,etab are set in behind_ua
  pb1=((rb1/rb0)^gb)*(pb0+pib)-pib;
  pa1=1/aa1*(P-ab1*pb1-ab1*rb1*(ub1-ua1)^2);

  U1(1)=aa1;
  U1(2)=ra1;
  U1(3)=ua1;
  U1(4)=pa1;
  U1(5)=rb1;
  U1(6)=ub1;
  U1(7)=pb1;
