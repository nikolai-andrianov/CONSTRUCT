function U1=sample(U,lr,WAVETYPE,SIGN_SPEED,par)

%  Samples the solution, i.e., fills the array data.
%  starting from the current wave, where the state before it is U,
%  in the direction lr.


  globals 	

  FAMILY=str2num(WAVETYPE(1));	%  0, 1 or 2
  TYPE=WAVETYPE(2);	%  's', 'r', 'c', or 'f' (fill)

  U1=NaN;		%  To avoid that U1 will be undefined if the wave is not admissible.

  z0=U(1);
  h0=U(2);
  v0=U(3);

  sign_speed=signalspeeds;

  		
%##############################################################################
%  Shock
%##############################################################################

  if TYPE == 's'

    s=par;		%  par is now the shock speed

    if ((x0+s*t > XB) | (x0+s*t < XA))
      str1=['The shock leaves the computational domain [' num2str(XA,16) ',' num2str(XB,16) ']!'];
      str2='Please reduce the shock speed or change the domain.';
      str=str2mat(str1,str2);
      hp=errordlg(str);
      uiwait(hp);
      return;
    end

    if ((lr == 'l') & (s > SIGN_SPEED))
      str1='Cannot connect the current state with shock from the left!';
      str2=[' Shock speed s=' num2str(s,16) '>' num2str(SIGN_SPEED,16) ' (current left signal speed)'];
      str=str2mat(str1,str2);
      hp=errordlg(str);         uiwait(hp)
      return;
    end

    if ((lr == 'r') & (s < SIGN_SPEED))
      str1='Cannot connect the current state with shock from the right!';
      str2=[' Shock speed s=' num2str(s,16) '<' num2str(SIGN_SPEED,16) ' (current right signal speed)'];
      str=str2mat(str1,str2);
      hp=errordlg(str);
      uiwait(hp);
      return;
    end

    m=h0*(v0-s);
    h1=-h0/2+h0/2*sqrt(1+8*m^2/(g*h0^3));

    if h1 < 1e-10
      str1='Non-positive water height behind the shock!';
      str2=['Height h=' num2str(h1,16)];
      str=str2mat(str1,str2);
      hp=errordlg(str);         uiwait(hp)
      return;
    end

    v1=m/h1+s;


%  Checks:

    if abs(h0*(v0-s)-h1*(v1-s)) > 1e-10
      msgbox('beda in mass balance...')
      disp(num2str(h0*(v0-s)-h1*(v1-s)),16)
    end
    if abs(h0*v0*(v0-s)+g/2*h0^2 - h1*v1*(v1-s)-g/2*h1^2) > 1e-10
      msgbox('beda in momentum balance..')
      disp(num2str(h0*v0*(v0-s)+g/2*h0^2 - h1*v1*(v1-s)-g/2*h1^2,16))
    end

    if lr == 'l'

      if ((FAMILY == 1) & ((h0 < h1) | (v0 > v1)))
        str1='Non-admissible 1-shock!';
        if h0 < h1, str2=['Water height behind the shock h0=' num2str(h0,16) '<' num2str(h1,16) '=h1 (height before the shock)'];end
        if v0 > v1, str2=['Velocity behind the shock v0=' num2str(v0,16) '>' num2str(v1,16) '=v1 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      if ((FAMILY == 2) & ((h1 < h0) | (v1 < v0)))
        str1='Non-admissible 2-shock!';
        if h1 < h0, str2=['Water height behind the shock h1=' num2str(h1,16) '<' num2str(h0,16) '=h0 (height before the shock)'];end
        if v1 < v0, str2=['Velocity behind the shock v1=' num2str(v1,16) '<' num2str(v0,16) '=v0 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      sign_speed(1)=s;		%  Can connect the current state with the shock from the left;
      				%  => left signal speed = s.
      				
%  For sampling:
      xx=x0+s*t;		%  (t,xx) is the point on the shock wave
      ic=floor((xx-XA)/dx +0.5);	%  Closest integer below xx
      di=-1;
      iend=1;

    else

      if ((FAMILY == 1) & ((h1 < h0) | (v1 > v0)))
        str1='Non-admissible 1-shock!';
        if h1 < h0, str2=['Water height behind the shock h1=' num2str(h1,16) '<' num2str(h0,16) '=h0 (height before the shock)'];end
        if v1 > v0, str2=['Velocity behind the shock v1=' num2str(v1,16) '>' num2str(v0,16) '=v0 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;

      end

      if ((FAMILY == 2) & ((h0 < h1) | (v0 < v1)))
        str1='Non-admissible 2-shock!';
        if h0 < h1, str2=['Water height behind the shock h0=' num2str(h0,16) '<' num2str(h1,16) '=h1 (height before the shock)'];end
        if v0 < v1, str2=['Velocity behind the shock v0=' num2str(v0,16) '<' num2str(v1,16) '=v1 (velocity before the shock)'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end


      sign_speed(2)=s;		%  Can connect the current state with the shock from the right;
      				%  => right signal speed = s.
      				
%  For sampling:
      xx=x0+s*t;		%  (t,xx) is the point on the shock wave
      ic=ceil((xx-XA)/dx +0.5);	%  Closest integer above xx
      di=1;			%  Step
      iend=mx;			%  Sample until

    end


%------------------------------------------------------------------------------
%  Sample the solution at the time t to the left or right of s
%------------------------------------------------------------------------------

    for i=ic:di:iend
      data(i,2)=h1;		%  Fill data with parameters until i=1
      data(i,3)=v1;
    end


  end


%##############################################################################
%  Rarefaction
%##############################################################################

  if TYPE == 'r'

    c0=sqrt(g*h0);

    if FAMILY == 1
      rartype=-1;	%  1-rarefaction
    else
      rartype=1;	%  2-rarefaction
    end

    l1=v0+rartype*c0;	%  Begin of the rarefaction


    v1=par;		%  par now is the velocity behind the rarefaction
    h1=1/(4*g)*(rartype*(v1-v0)+2*c0)^2;
    c1=sqrt(g*h1);

%  Check:

%    if abs(v0-rartype*2*c0-v1+rartype*2*sqrt(g*h1)) > 1e-10
%      msgbox('beda in rarefaction...')
%      disp(num2str(v0-rartype*2*c0-v1+rartype*2*c1,16))
%      pause
%    end

    l2=v1+rartype*c1;	%  End of the rarefaction

    spd=max(abs(l1),abs(l2));
    if spd == abs(l1), spd=l1;end
    if spd == abs(l2), spd=l2;end

    if ((x0+spd*t > XB) | (x0+spd*t < XA))
      str1=['The rarefaction leaves the computational domain [' num2str(XA,16) ',' num2str(XB,16) ']!'];
      str2='Please change the rarefaction parameters or the domain.';
      str=str2mat(str1,str2);
      hp=errordlg(str);         uiwait(hp)
      return;
    end


    if lr == 'l'

      if l1 > SIGN_SPEED
        str1='Cannot connect the current state with rarefaction from the left!';
        str2=[' Rarefaction begin l1=' num2str(l1,16) '>' num2str(SIGN_SPEED,16) ' (current left signal speed)'];
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end


      if ((FAMILY == 1) & ((h0 > h1) | (v0 < v1)))
        str1='Non-admissible 1-rarefaction!';
        if h0 > h1, str2=['Pressure behind the rarefaction h0=' num2str(h0,16) '>' num2str(h1,16) '=h1 (pressure before the rarefaction)'];end
        if v0 < v1, str2=['Velocity behind the rarefaction v0=' num2str(v0,16) '<' num2str(v1,16) '=v1 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      if ((FAMILY == 2) & ((h1 > h0) | (v1 > v0)))
        str1='Non-admissible 2-rarefaction!';
        if h1 > h0, str2=['Pressure behind the rarefaction h1=' num2str(h1,16) '>' num2str(h0,16) '=h0 (pressure before the rarefaction)'];end
        if v1 > v0, str2=['Velocity behind the rarefaction v1=' num2str(v1,16) '>' num2str(v0,16) '=v0 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      sign_speed(1)=l2;		%  Can connect the current state with the rarefaction from the left;
      				%  => left signal speed = char. speed at the end of rarefaction.
    		
%  For sampling:
      xl1=x0+l1*t;
      il1=floor((xl1-XA)/dx +0.5);	%  Index, corresponding to the begin of the rarefaction
      xl2=x0+l2*t;
      il2=ceil((xl2-XA)/dx +0.5);	%  Index, corresponding to the end of the rarefaction

      a=(il1-0.5)*dx;		%  Corresponding x's.
      b=(il2-0.5)*dx;
      di=-1;
      iend=1;			%  Sample until

    else

      if l1 < SIGN_SPEED
        str1='Cannot connect the current state with rarefaction from the right!';
        str2=[str1 ' Rarefaction begin l1=' num2str(l1,16) '<' num2str(SIGN_SPEED,16) ' (current right signal speed)'];
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      if ((FAMILY == 1) & ((h1 > h0) | (v1 < v0)))
        str1='Non-admissible 1-rarefaction!';
        if h1 > h0, str2=['Water height behind the rarefaction h1=' num2str(h1,16) '>' num2str(h0,16) '=h0 (height before the rarefaction)'];end
        if v1 < v0, str2=['Velocity behind the rarefaction v1=' num2str(v1,16) '<' num2str(v0,16) '=v0 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      if ((FAMILY == 2) & ((h0 > h1) | (v0 > v1)))
        str1='Non-admissible 2-rarefaction!';
        if h0 > h1, str2=['Water height behind the rarefaction h0=' num2str(h0,16) '>' num2str(h1,16) '=h1 (height before the rarefaction)'];end
        if v0 > v1, str2=['Velocity behind the rarefaction v0=' num2str(v0,16) '>' num2str(v1,16) '=v1 (velocity before the rarefaction )'];end
        str=str2mat(str1,str2);
        hp=errordlg(str);         uiwait(hp)
        return;
      end

      sign_speed(2)=l2;		%  Can connect the current state with the rarefaction from the right;
      				%  => right signal speed = char. speed at the end of rarefaction.
      				
     	
%  For sampling:
      xl1=x0+l1*t;
      il1=floor((xl1-XA)/dx +0.5);	%  Index, corresponding to the begin of the rarefaction
      xl2=x0+l2*t;
      il2=ceil((xl2-XA)/dx +0.5);	%  Index, corresponding to the end of the rarefaction

      a=(il1-0.5)*dx;		%  Corresponding x's.
      b=(il2-0.5)*dx;
      di=1;
      iend=mx;			%  Sample until

    end


%------------------------------------------------------------------------------
%  Sample the solution at the time t in the rarefaction and to the left(right) of it
%------------------------------------------------------------------------------

    for i=il1:di:il2		%  Solution in the rarefaction fan

     xx=(i-0.5)*dx;		%  Current x

     if abs(b-a) > 1e-8
	xrel=(xx-a)/(b-a);
     else
	xrel=0;
     end
	
     xt=l1*(1-xrel)+l2*xrel;
     h=1/(9*g)*(2*c0-rartype*(v0-xt))^2;
     v=xt-rartype*sqrt(g*h);

     data(i,2)=h;		%  Fill data with parameters
     data(i,3)=v;

    end

    for i=il2:di:iend
        data(i,2)=h1;		%  Fill data with parameters until i=iend
        data(i,3)=v1;
    end
	


  end


%##############################################################################
%  Contact
%##############################################################################

  if TYPE == 'c'

  if ((x0+0*t > XB) | (x0+0*t < XA))	%  we have only stationary contact with speed=0
      str1=['The stationary contact is out of the computational domain [' num2str(XA,16) ',' num2str(XB,16) ']!'];
      str2='Please change the domain.';
      str=str2mat(str1,str2);
      hp=errordlg(str);
      uiwait(hp)
      return;
  end

  U1=U;			%  Set U1=U0, only for check if the solid contact is not out of domain

  if lr == 'l'

        xx=x0+0*t;		%  we have only stationary contact with speed=0
        ic=floor((xx-XA)/dx +0.5);	%  Current index of X: Closest integer below X
        for i=ic:-1:1
          for k=1:3
            data(i,k)=U(k);	%  Fill data with U0 until i=1
          end
        end

  else

        xx=x0+0*t;
        ic=ceil((xx-XA)/dx +0.5);	%  Current index of X: Closest integer above X
        for i=ic:+1:mx
          for k=1:3
            data(i,k)=U(k);	%  Fill data with U1 until i=mx
          end
        end

  end

  return;


  end

%##############################################################################
%  Fill data with U from lr-side, starting from speed SIGN_SPEED (used to Edit wave )
%##############################################################################

  if TYPE == 'f'	%  fill

    h1=h0;
    v1=v0;

    if lr == 'l'

      sign_speed(1)=SIGN_SPEED;	%  Set the left signal speed

%  Sample the solution at the time t to the left of SIGN_SPEED

      xx=x0+SIGN_SPEED*t;
      ic=floor((xx-XA)/dx +0.5);	%  Closest integer below xx
      for i=ic:-1:1
        data(i,2)=h1;		%  Fill data with parameters until i=1
        data(i,3)=v1;
      end

    else

      sign_speed(2)=SIGN_SPEED;	%  Set the right signal speed

%  Sample the solution at the time t to the right of s

      xx=x0+SIGN_SPEED*t;
      ic=ceil((xx-XA)/dx +0.5);	%  Closest integer above xx
      for i=ic:+1:mx
        data(i,2)=h1;		%  Fill data with parameters until i=mx
        data(i,3)=v1;
      end

    end

  end


%##############################################################################
%  Common for every wave, apart from the 0-contact
%##############################################################################


  U1(1)=U(1);		%  Bottom topography does not change across the waves
  U1(2)=h1;
  U1(3)=v1;
  signalspeeds=sign_speed;

%##############################################################################
%  Plot currently requested data in the top axes
%##############################################################################

  axes(axes2);		%  Draw in the top axes
  parnum=get(choose_param, 'Value');
  plot(x,data(:,parnum), colour(parnum));
  xlim([XA XB]);

%##############################################################################

