function U1=inputsc

%  Creates a dialog window to enter the values around the stationary contact, i.e.
%  sets the values of global varaibles U0,z1
%  Checks if they are positive if necessary.
%
%  With these parameters, tries to find the state behind the stationary contact,
%  asking to correct the values of U0,z1, if there are no roots.
%
%  Input parameters (U,z1) serve as a default values for the dialog entries.
%  Returns the state U1 behind the stationary contact.

  globals

  U1=[];

  U0old=U0;				%  Save for the case if bad values will be entered
  z1old=z1;

  okay=0;
  stp=0;
  while ~okay

    okay=1;

    prompt={'Bottom topography at the left';
              'Water height at the left';
              'Water velocity at the left';
              'Bottom topography at the right'};
    def={num2str(U0(1),16);num2str(U0(2),16);num2str(U0(3),16);num2str(z1,16)};

    title='Enter the stationary contact';
    lines=1;

    answer=inputdlg(prompt,title,lines,def);
    if isempty(answer),stp=1;return;end

%  Read the new values for U0

    stp=0;
    for i=1:3
      U0(i)=str2double(answer(i));
      if ((U0(i) <= 0) & ((i ~= 3)))
        par=cell2struct(prompt(i),'name');
        h=errordlg(['Please enter POSITIVE ' lower(par.name) '!']);
        uiwait(h);
        okay=0;
      end
    end

    z1=str2double(answer(4));
    if z1 <= 0
      h=errordlg('Please enter POSITIVE bottom topography at the right!');
      uiwait(h);
      okay=0;
    end


    h1=behind_sc;		%  Calculates h1 using just entered U0,z1

    if isempty(h1),okay=0;end

  end

  if stp,return,end		%  This is executed only if smb has pressed cancel.. Then return U1=[]

%  At this point, U0 is okay, so we can calculate U1 without problems..

  z0=U0(1);
  h0=U0(2);
  v0=U0(3);

  v1=M/h1;	%  Global M is set in behind_sc

  U1(1)=z1;
  U1(2)=h1;
  U1(3)=v1;



