function modifymenu(WAVETYPE,pm)

%  Removes all waves with the same family as the current wave from cmenu1  (pm='-')
%  Adds the waves of the same family as the current wave (pm='+')

%------------------------------------------------------------------------------
% Declare global variables
%------------------------------------------------------------------------------

  globals
  NewWavename='';
  NewWavetype='';
  k=0;

  if pm == '-'
    for i=1:Nwaves
      if (wavetype(i,1) ~= WAVETYPE(1))
          k=k+1;
          if isempty(NewWavename)
              NewWavename=wavename(i,:);
              NewWavetype=wavetype(i,:);
          else
              NewWavename=[NewWavename;wavename(i,:)];
              NewWavetype=[NewWavetype;wavetype(i,:)];
          end
      end
    end

  else

    orig_Nwaves=4;
    k=Nwaves;
    NewWavename=wavename;
    NewWavetype=wavetype;
    for i=1:orig_Nwaves
      if (orig_wavetype(i,1) == WAVETYPE(1))
        NewWavename=[NewWavename;orig_wavename(i,:)];
        NewWavetype=[NewWavetype;orig_wavetype(i,:)];
        k=k+1;
       end
     end

  end

  for i=1:Nwaves
    delete(CSTR_Addmenu(i));		% Delete the old menu items
  end

  Nwaves=k;
  wavename=NewWavename;
  wavetype=NewWavetype;

  for i=1:Nwaves
   CSTR_Addmenu(i)=uimenu(CSTR_ADDMENU,'Label',wavename(i,:),'Callback', ['callbacks(' num2str(300+i) ');']);
  end
