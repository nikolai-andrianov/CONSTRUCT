%  Global variables

%  Handles of main window and menuitems save, print, ..
    global MainWindow hp11 hp12 hp13 hp14 hp2 charact axes1 axes2 choose_param varnames CSTR_Addmenu CSTR_ADDMENU
    global cmenu1 cmenu2 cmenu3							%  addmenu is reserved (standard function)

%  Color and linewidth
    global Color CRLineWidth ShockLineWidth

%  Structures and their dimensions
    global Nwaves Nchar N			%  Number of items in wave menu, number of drawn characteristics and waves
    global colour wavename wavetype wave0 wave orig_wavename orig_wavetype paramname	%  See construct.m

%  Some input parameters
    global g					%  Gravity constant
    global U00 U0 				%  State U0 to the left of the stationary contact
    global XA XB XLIM YLIM x0 t mx x dx data	%  Domain, x and the data arrays

%  Used in behind_sc.m
    global z1 M E 

%  Filename and remark to solution
    global filename remark

%  Gas and solid control speeds
    global signalspeeds
