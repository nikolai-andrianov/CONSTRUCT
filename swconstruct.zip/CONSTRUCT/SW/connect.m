function U1=connect(U,lr,WAVETYPE,SIGN_SPEED,par);

%  Connect the state U with U1, using the wave of WAVETYPE.
%  par is the given parameter at U1.
%  SIGN_SPEED is the current left or right (depending on lr) signal speed.


  globals 	

  PHASE=WAVETYPE(1);	%  's' or 'g'
  FAMILY=str2num(WAVETYPE(2));	%  1 or 3
  TYPE=WAVETYPE(3);	%  's' or 'r'

  aa0=U(1);
  ra0=U(2);
  ua0=U(3);
  pa0=U(4);
  rb0=U(5);
  ub0=U(6);
  pb0=U(7);

  if PHASE == 's'
      g=ga;
      pi=pia;
      r0=ra0;
      u0=ua0;
      p0=pa0;
  else
      g=gb;
      pi=pib;
      r0=rb0;
      u0=ub0;
      p0=pb0;
  end

  		
%##############################################################################
%  Shock
%##############################################################################

  if TYPE == 's'

    s=par;		%  par is now the shock speed

    if ((lr == 'l') & (s > SIGN_SPEED))
%      errordlg('Cannot connect the current state with shock from the left!');
      str='Cannot connect the current state with shock from the left!';
      str=[str ' Shock speed s=' num2str(s) '>' num2str(SIGN_SPEED) ' (current left signal speed)'];
      set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
      break;
    end

    if ((lr == 'r') & (s < SIGN_SPEED))
%      errordlg('Cannot connect the current state with shock from the right!');
      str='Cannot connect the current state with shock from the right!';
      str=[str ' Shock speed s=' num2str(s) '<' num2str(SIGN_SPEED) ' (current right signal speed)'];
      set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
      break;
    end


    mu2=(g-1)/(g+1);		%  Formulae from Courant and Friedrichs, p. 150.
    v0=u0-s;
    c2=g*(p0+pi)/r0;
    M0=abs(v0/sqrt(c2));

    p1=p0*(M0*M0*(1+mu2)-mu2)+g*pi*(1-mu2)*(M0*M0-1);

    if p1 < 0
%      errordlg(['Negative pressure behind the shock!']);

      str='Negative pressure behind the shock!';
      str=[str ' pressure p=' num2str(p1)];
      set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
      break;


    end

    cstar2=mu2*v0^2 + (1-mu2)*c2;
    v1=cstar2/v0;
    u1=v1+s;
    c2=(cstar2-mu2*v1*v1)/(1-mu2);
    r1=g*(p1+pi)/c2;

    if lr == 'l'

      if ((FAMILY == 1) & (p0 < p1))
%        errordlg(['Non-admissible 1-shock!']);
        str='Non-admissible 1-shock!';
        str=[str 'Pressure behind the shock p0=' num2str(p0) '<' num2str(p1) '=p1 (pressure before the shock)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      if ((FAMILY == 3) & (p1 < p0))
%        errordlg(['Non-admissible 3-shock!']);
        str='Non-admissible 3-shock!';
        str=[str 'Pressure behind the shock p1=' num2str(p1) '<' num2str(p0) '=p0 (pressure before the shock)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      sign_speed(1)=s;		%  Can connect the current state with the shock from the left;
      				%  => left signal speed = s.

    else

      if ((FAMILY == 1) & (p1 < p0))
%        errordlg(['Non-admissible 1-shock!']);
        str='Non-admissible 1-shock!';
        str=[str 'Pressure behind the shock p1=' num2str(p1) '<' num2str(p0) '=p0 (pressure before the shock)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;

      end

      if ((FAMILY == 3) & (p0 < p1))
%        errordlg(['Non-admissible 3-shock!']);
        str='Non-admissible 3-shock!';
        str=[str 'Pressure behind the shock p0=' num2str(p0) '<' num2str(p1) '=p1 (pressure before the shock)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end


      sign_speed(2)=s;		%  Can connect the current state with the shock from the right;
      				%  => right signal speed = s.

    end

  end


%##############################################################################
%  Rarefaction
%##############################################################################

  if TYPE == 'r'

    c0=sqrt(g*(p0+pi)/r0);

    if FAMILY == 1
      rartype=-1;	%  1-rarefaction		
    else
      rartype=1;		%  3-rarefaction
    end

    l1=u0+rartype*c0;	%  Begin of the rarefaction

    if par <= 0
      errordlg(['Enter POSITIVE pressure behind the rarefaction!']);
      break;
    end

    p1=par;		%  par now is the pressure behind the rarefaction

    r1=r0*((p1+pi)/(p0+pi))^(1/g);	%  Density
    c1=sqrt(g*(p1+pi)/r1);		%  Sound speed                              	
    u1=u0+rartype*2*c0/(g-1)*( ((p1+pi)/(p0+pi))^((g-1)/2/g)-1 );

    l2=u1+rartype*c1;	%  End of the rarefaction

%    if abs(l1) > abs(l2)
%      str=[str 'Pressure behind the shock p0=' num2str(p0) '<' num2str(p1) '=p1 (pressure before the shock)'];
%      set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
%      break;
%    end


    if lr == 'l'

      if l1 > SIGN_SPEED
        str='Cannot connect the current state with rarefaction from the left!';
        str=[str ' Rarefaction begin l1=' num2str(l1) '>' num2str(SIGN_SPEED) ' (current left signal speed)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end


      if ((FAMILY == 1) & (p0 > p1))
        str='Non-admissible 1-rarefaction!';
        str=[str 'Pressure behind the rarefaction p0=' num2str(p0) '>' num2str(p1) '=p1 (pressure before the rarefaction)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      if ((FAMILY == 3) & (p1 > p0))
        str='Non-admissible 3-rarefaction!';
        str=[str 'Pressure behind the rarefaction p1=' num2str(p1) '>' num2str(p0) '=p0 (pressure before the rarefaction)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      sign_speed(1)=l2;		%  Can connect the current state with the rarefaction from the left;
      				%  => left signal speed = char. speed at the end of rarefaction.

    else

      if l1 < SIGN_SPEED
        str='Cannot connect the current state with rarefaction from the right!';
        str=[str ' Rarefaction begin l1=' num2str(l1) '<' num2str(SIGN_SPEED) ' (current right signal speed)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      if ((FAMILY == 1) & (p1 > p0))
        str='Non-admissible 1-rarefaction!';
        str=[str 'Pressure behind the rarefaction p1=' num2str(p1) '>' num2str(p0) '=p0 (pressure before the rarefaction)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      if ((FAMILY == 3) & (p0 > p1))
        str='Non-admissible 3-rarefaction!';
        str=[str 'Pressure behind the rarefaction p0=' num2str(p0) '>' num2str(p1) '=p1 (pressure before the rarefaction)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      sign_speed(2)=l2;		%  Can connect the current state with the rarefaction from the right;
      				%  => right signal speed = char. speed at the end of rarefaction.
      				

    end

  end


%##############################################################################
%  Gas contact
%##############################################################################

  if TYPE == 'c'

  if lr == 'l'

      if u0 > SIGN_SPEED
        str='Cannot connect the current state with gas contact from the left!';
        str=[str ' Contact speed u0=' num2str(u0) '>' num2str(SIGN_SPEED) ' (current left signal speed)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      sign_speed(1)=u0;		%  Can connect the current state with the contact from the left;
      				%  => left signal speed = speed of contact.


   else

      if u0 < SIGN_SPEED
        str='Cannot connect the current state with gas contact from the right!';
        str=[str ' Contact speed u0=' num2str(u0) '<' num2str(SIGN_SPEED) ' (current left signal speed)'];
        set(sc1txt(11), 'Visible', 'on', 'String', str, 'ForegroundColor', [1 0 0]);
        break;
      end

      sign_speed(2)=u0;		%  Can connect the current state with the contact from the right;
      				%  => right signal speed = speed of contact.


   end

    if par <= 0
      errordlg(['Enter POSITIVE density behind the contact!']);
      break;
    end

    r1=par;
    u1=u0;
    p1=p0;

  end



%##############################################################################
%  Common for every wave
%##############################################################################


  U1(1)=U(1);		%  Solid volume fraction does not change across the waves

  if PHASE == 's'

      U1(2)=r1;		%  Current wave is solid; r1, u1, p1 are just found
      U1(3)=u1;
      U1(4)=p1;
      U1(5)=U(5);	%  Gas parameters do not change across solid wave
      U1(6)=U(6);
      U1(7)=U(7);

  else

      U1(2)=U(2);	%  Solid parameters do not change across gas wave
      U1(3)=U(3);
      U1(4)=U(4);
      U1(5)=r1;		%  Current wave is solid; r1, u1, p1 are just found
      U1(6)=u1;
      U1(7)=p1;

  end







