function construct

% ##################################################################################
%  Construct the exact solution to the Riemann problem for the Shallow Water equations
% ##################################################################################


%------------------------------------------------------------------------------
% Declare global variables
%------------------------------------------------------------------------------

  globals

%------------------------------------------------------------------------------
% Initialize
%------------------------------------------------------------------------------

%######################################
%  Constants

  Color='k';		%  Color for waves, characteristics, and graphs
  CRLineWidth=1;	%  Linewidth for Contact or Rarefaction
  ShockLineWidth=2;     %  Linewidth for Shock

%  Number of waves, which can be drawn (what appears in menu)

  Nwaves=4;

%  Number of drawn waves
  N=0;

%  Number of drawn characteristics
  Nchar=0;

  wavename=['1-shock      ';
	    '1-rarefaction';
	    '2-shock      ';
	    '2-rarefaction'];

  orig_wavename=wavename;

  wavetype=['1s';
	    '1r';
	    '2s';
	    '2r'];

  orig_wavetype=wavetype;

  paramname=['Bottom topography';
             'Water height     ';
             'Water velocity   '];
  colour=['k','k','k'];                %  Draw all parameters in black


%  varnames=['aa0';'ra0';'ua0';'pa0';'rb0';'ub0';'pb0';'aa1';'ra1'];

  varnames=['z';'h';'v'];


%######################################
%  Main window

  FigWidth=0.6;
  FigHeight=0.8;

  FigPos(1)=(1-FigWidth)/2;
  FigPos(2)=(1-FigHeight)/2;
  FigPos(3)=FigWidth;
  FigPos(4)=FigHeight;

  MainWindow=figure;
  set(MainWindow,'Units','normalized', ...
  	 'Position', FigPos,...
  	 'NumberTitle','off', ...
  	 'MenuBar','None',...
  	 'Name','Construction of Riemann Problem');

%  Menu  	
  	
  hp1=uimenu('Label', 'File');
  uimenu(hp1, 'Label', 'New..','Callback', 'callbacks(0);')
  uimenu(hp1, 'Label', 'Open..','Callback', 'callbacks(1);');
  hp11=uimenu(hp1, 'Label', 'Save configuration','Separator','On','Enable','Off','Callback', 'callbacks(5);');
  hp12=uimenu(hp1, 'Label', 'Save solution','Enable','Off','Callback', 'callbacks(6);');
  hp13=uimenu(hp1, 'Label', 'Print configuration',...
  		 'Enable','Off','Separator','On',...
  		 'Callback', 'callbacks(8);');
  hp14=uimenu(hp1, 'Label', 'Print solution','Enable','Off','Callback', 'callbacks(7);');
  uimenu(hp1, 'Label', 'Quit','Separator','On','Callback', 'callbacks(2);');

  hp2=uimenu('Label', 'Edit','Enable','Off');
  uimenu(hp2, 'Label', 'Domain','Callback', 'callbacks(10);');
  uimenu(hp2, 'Label', 'Gravity constant','Callback', 'callbacks(11);');

  hp3=uimenu('Label', 'Help','Enable','On');
  uimenu(hp3, 'Label', 'Contents..','Callback', 'callbacks(12);');
  uimenu(hp3, 'Label', 'About..','Separator','On','Callback', 'callbacks(13);');


%  Set some uicontrols empty

  axes1=[];		%  Bottom axes, for configuration
  axes2=[];		%  Top axes, for graphs
  choose_param=[];	%  Popup for parameters to draw
  CSTR_Addmenu=[];		%  Context menu
  charact=[];		%  Characteristics

%  .. and also some parameters
  g=2;
  U0=[];
  wave0=[];
  filename='';
  remark='';
  answer={''};

