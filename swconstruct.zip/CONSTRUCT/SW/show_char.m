function characts = show_char(xc,tc,U);

%  Show the characteristics at the state U.
%  Returns handles to the graphs of characteristics.

  globals

  h=U(2);
  v=U(3);

  c=sqrt(g*h);

%  Set the size of characteristics
  T=get(axes1, 'YLim');
  dT=(T(2)-T(1))/4;		%  The t-component of the line is 1/4 of current t-scale

  speed=v-c;
  characts(1)=plot([xc xc+speed*dT], [tc, tc+dT], Color);
  speed=v+c;
  characts(2)=plot([xc xc+speed*dT], [tc, tc+dT], Color);

  for i=1:2
    set(characts(i),'UIContextMenu', cmenu3,'Visible','on');
  end
