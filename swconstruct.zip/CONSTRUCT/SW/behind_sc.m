function h1=behind_sc

%  Evaluates the state U1 behind the stationary contact.

  globals

  h1=[];		% Returns the empty value if coinciding contacts or no roots
  EPS=1e-8;

  z0=U0(1);
  h0=U0(2);
  v0=U0(3);

  M=h0*v0;
  E=0.5*v0^2 + g*(z0+h0);

  if (abs(v0)<=EPS)
    h1=h0+z0-z1;
    v1=v0;
    return;
  end

  hstar=( M^2/g )^(1/3);

  h=hstar/2;		% /* Initial guess to find the smallest root */
  interv(1)=0;		% /* Interval bounds for the smallest root */
  interv(2)=hstar;

  use_fzero=0;
  for i=1:2

      FF=1;
      niter=0;

      while (abs(FF)>EPS)

         niter=niter+1;		%	/* Number of iterations */
         if (rem(niter,100) == 0)
            disp([num2str(niter) ' iterations in finding the ' num2str(i) ' root behind the stat. contact..']);
            disp('Using fzero..');
            use_fzero=1;
            break;
         end;

	 if (abs(h) <= EPS)
	   disp('In finding the root behind the stat. contact h=0..');
	   disp('Using fzero..');
	   use_fzero=1;
	   break;
	 end

         FF=0.5*(M/h)^2 + g*(z1+h) - E;	 	%   /* F(h) */
	 Fder=-M*M/(h^3) + g;		%   /* F'(h)*/

         if (abs(Fder)<EPS),disp('In finding the state behind the stationary contact, |F`(h)|<EPS !!');end;

         if (Fder==0)
            disp('In finding the state behind the stationary contact, |F`(h)|=0 !!');
            return;
         end

         h=h-FF/Fder;		%  /* Newton iteration */

         if (h < interv(1)),h=EPS;end;
         if (h > interv(2)),h=hstar-EPS;end;

      end

      if (use_fzero),break,end;

      if (i==1)
        h11=h;
        h=3*hstar/2;		% /* Initial guess to find the biggest root */
        interv(1)=hstar;	% /* Interval bounds for the biggest root */
        interv(2)=1e10;		% /* Some big value */
      else
        h12=h;
      end

  end

  if (use_fzero)
    h11=fzero('F',hstar);
    h12=fzero('F',h0);
  end


  if (isnan(h11) | isnan(h12) | (h11<0) | (h12<0))	%  Both 2 roots must be positive
     str=['F(h1)=0 has no roots! Please change the parameters at the stationary contact.'];
     hp=errordlg(str);
     uiwait(hp);
     return;
  end

  if sign(-v0^2+g*h0) == 0
     str1='Sonic state attached to the solid contact at the left !!';
     str2='Exiting..';
     str=str2mat(str1,str2);
     hp=errordlg(str);
     uiwait(hp);
     h1=[];
     return;
  end

%  Determine which one is admissible

  v11=M/h11;
  v12=M/h12;

  found=0;
  if sign(-v11^2+g*h11) == sign(-v0^2+g*h0)		%  h11 admissible
    h1=h11;
    found=1;
  end

  if sign(-v12^2+g*h12) == sign(-v0^2+g*h0)		%  h12 admissible
    h1=h12;
    found=1;
  end


  if ~found

% Check if the roots are different

    stp=0;
    while (abs(h11-h12) < 1e-8)

      hstar=h0;
      fp=figure;
      set(fp, 'NumberTitle','Off','Name','Graph of F(h)');

      if h11 < hstar
        AH=h11;
        BH=hstar+(hstar-h11)/2;
      else
        AH=max(0.0001, hstar-(h11-hstar)/2);
        BH=h11;
      end

      dh=(BH-AH)/100;
      h=[AH:dh:BH];

      plot(h,F(h));
      title('Graph of F(h)');
      ylabel('F(h)');
      xlabel('h');

      Title='Find zero of F(h)=0';
      str1='Across the stationary contact, the equation F(h)=0 has two roots.';
      str2=['With the following starting guess fzero.m has converged to ' num2str(h11)];
      str3='Enter another starting guess to find the second root:';
      prompt=str2mat(str1,str2,str3);
      def={num2str(hstar)};
      parstr=inputdlg(prompt,Title,1,def);
      if isempty(parstr),stp=1;delete(fp);return;end;
      hstar=str2double(parstr);
      if (isnan(hstar) | hstar < 0)
        hp=errordlg(['Please enter a positive NUMBER!']);
        uiwait(hp);
        delete(fp);
      else
        h12=fzero('F',hstar);
        delete(fp);
        if (isnan(h12)),h12=h11;end;
      end

    end


%  Check:

     v1=M/h1;
     E1=0.5*v1^2 + g*(z1+h1);

     if abs(E1-E) > EPS
       hp=errordlg(['Error in behind_sc: E1-E2' num2str(E1-E2)]);
       uiwait(hp);
       return;
     end


  end





