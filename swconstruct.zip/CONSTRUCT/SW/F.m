function Y=F(h1);

%  Determines the function F(h1).

  globals

%  z1 is defined in behind_sc and is a global variable
  Y = 0.5*(M./h1).^2 + g*(z1+h1) - E;

