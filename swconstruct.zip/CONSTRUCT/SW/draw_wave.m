function WAVE=draw_wave(U,U1,WAVENAME,WAVETYPE,par)

%  Draws the wave of the type WAVETYPE, which
%  connects the state U with U1.
%  par is useful only in case of shock and is equal
%  to shock speed.

  globals 	

  axes(axes1);		%  Draw in the bottom axes

  FAMILY=str2num(WAVETYPE(1));	%  0, 1 or 2
  TYPE=WAVETYPE(2);	%  's' or 'r'

  NN=60;
  Dx=1/NN;	%  Draw the rarefaction fan with the distance >= Dx between the lines

  h0=U(2);
  v0=U(3);

  h1=U1(2);
  v1=U1(3);

  height=2/3;
 
  if TYPE == 's'
     LineWidth=ShockLineWidth;
  else
     LineWidth=CRLineWidth;
  end


   if TYPE == 'c'		%  Contact
     speed=0;			%  Contact speed
     height=5/6;
     position=speed*t;
     txt='';
     alignment='right';
   end

   if TYPE == 'r'	 	%  Rarefaction

     c0=sqrt(g*h0);
     c1=sqrt(g*h1);

     if FAMILY == 1
      rartype=-1;	%  1-rarefaction
     else
      rartype=1;	%  3-rarefaction
    end

    speed1=min(v0+rartype*c0, v1+rartype*c1);	%  The min char. in the rarefaction
    speed2=max(v0+rartype*c0, v1+rartype*c1);	%  The max char. in the rarefaction

    if FAMILY == 1
       txt='1-rarefaction\rightarrow';
       alignment='right';
       position=speed1*t;
    else
       txt='\leftarrow2-rarefaction';
       alignment='left';
       position=speed2*t;
    end

   end

   if TYPE == 's'		%  Shock

     speed=par;

     if FAMILY == 1
       txt='1-shock\rightarrow';
       alignment='right';
     else
       txt='\leftarrow2-shock';
       alignment='left';
     end

     position=speed*t;

   end



% #######################################
% Draw the waves 

   WAVE.name=WAVENAME;
   WAVE.type=WAVETYPE;

   if TYPE == 'r'

     WAVE.speed1=speed1;
     WAVE.speed2=speed2;
     x1=x0+speed1*t;
     x2=x0+speed2*t;
     m=round((x2-x1)/Dx);
     if m ~= 0
       deltax=(x2-x1)/m;
     else
       deltax=x2-x1;
     end
     for i=1:m+1
       xx=x1+(i-1)*deltax;
       WAVE.handle(i)=plot([x0 xx],[0 t],Color);
       set(WAVE.handle(i),'UIContextMenu', cmenu2,'Visible','on');
     end
     WAVE.handle(m+2)=text(x0+position*height,t*height,txt,'HorizontalAlignment',alignment);
     set(WAVE.handle(m+2),'UIContextMenu', cmenu2,'Visible','on');

   else

     WAVE.speed1=speed;
     WAVE.speed2=speed;
     WAVE.handle(1)=plot([x0 x0+speed*t], [0 t], Color);
     set(WAVE.handle(1), 'LineWidth',LineWidth,'UIContextMenu', cmenu2,'Visible','on');
     WAVE.handle(2)=text(x0+position*height,t*height,txt,'HorizontalAlignment',alignment);
     set(WAVE.handle(2),'UIContextMenu', cmenu2,'Visible','on');

   end

