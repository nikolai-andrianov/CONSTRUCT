function drawfig=draw(varargin)

%  If called without any arguments, asks for the data file with results,
%  and draws them.
%
%  If called with arguments, these should have the form
%  varargin{}={t,x,data}, where
%	t is the time
%	x is the array of x
%	data is the array of (z,h,v).
%
%  Returns the handle of the figure.


  if nargin == 0

%    prompt={'Print results from'};		%  Uncomment theses lines if you want graphic input
%    Title='Print solution';
%    lines=1;
%    fname=inputdlg(prompt,Title,lines);

    fname=input('Draw results from: ', 's');

    if isempty(fname),return;end

%    fname=cell2struct(fname,'str');		%  Uncomment theses lines if you want graphic input
%    fname=fname.str;

    fid = fopen(fname);
    if fid == -1
      disp(['Can''t open ' fname]);
      return;
    end
    str = fscanf(fid,'%s',1);			%  Get current time
    t=round(str2num(strrep(str,'t=',''))*100000)/100000;
    fscanf(fid,'%s %s',2);			%  Get 'Fields: ..'

    data = fscanf(fid,'%g',[4,inf]);
    data = data';
    fclose(fid);

    x=data(:,1);
    z=data(:,2);
    h=data(:,3);
    v=data(:,4);

  else

    t=varargin{1};
    x=varargin{2};
    data=varargin{3};
    z=data(:,1);
    h=data(:,2);
    v=data(:,3);

  end


%  Plotting..

  Color='k';
  Title='Flow parameters';

  FigWidth=0.6;
  FigHeight=0.23;

  FigPos(1)=(1-FigWidth)/2;
  FigPos(2)=(1-FigHeight)/2;
  FigPos(3)=FigWidth;
  FigPos(4)=FigHeight;

  drawfig=figure;
  set(drawfig,'Units','normalized', ...
  	 'Position', FigPos,...
  	 'NumberTitle','off', ...
  	 'Name',Title);

  subplot(1,3,1);
  plot(x,h,Color);
  xlim([min(x) max(x)]);
  title(['Water height at time t=',num2str(t) ]);

  subplot(1,3,2)
  plot(x,v,Color);
  xlim([min(x) max(x)]);
  title(['Velocity'])

  subplot(1,3,3)
  plot(x,z,Color);
  xlim([min(x) max(x)]);
  title(['Bottom topography'])

